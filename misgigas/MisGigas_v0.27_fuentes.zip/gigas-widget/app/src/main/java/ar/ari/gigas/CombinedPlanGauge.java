package ar.ari.gigas;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import java.util.Locale;

/** Both plans retain their own denominator; balances are never added together. */
final class CombinedPlanGauge {
 static final Locale LOCALE = new Locale("es", "AR");
 static double ratio(float total, float left) {
  return Float.isFinite(total) && Float.isFinite(left) && total > 0 && left >= 0 && left <= total
   ? (double) left / total : Double.NaN;
 }
 static String value(float total, float left) {
  return Double.isFinite(ratio(total,left)) ? String.format(LOCALE,"%.2f GB",left) : "—";
 }
 static String summary(float total,float left) {
  double r=ratio(total,left);
  return Double.isFinite(r)?String.format(LOCALE,"%.0f %% · de %.2f GB",100*r,total):"Sin lectura";
 }
 static Bitmap draw(Context context) {
  SharedPreferences prefs=Plan.prefs(context);
  return draw(prefs.getFloat("personaltotal",0),prefs.getFloat("personalleft",-1),
   prefs.getFloat("clarototal",0),prefs.getFloat("claroleft",-1));
 }
 static Bitmap draw(float pt,float pl,float ct,float cl) {
  Bitmap bitmap=Bitmap.createBitmap(600,390,Bitmap.Config.ARGB_8888);
  bitmap.setDensity(Bitmap.DENSITY_NONE);
  Canvas canvas=new Canvas(bitmap);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
  arc(canvas,paint,254,18,ratio(pt,pl));arc(canvas,paint,218,15,ratio(ct,cl));
  text(canvas,paint,"PERSONAL",300,146,23,0xffa5b7d0,false,Paint.Align.CENTER,310);
  text(canvas,paint,value(pt,pl),300,192,43,0xffe9f0fc,true,Paint.Align.CENTER,310);
  text(canvas,paint,"CLARO",300,227,23,0xffa5b7d0,false,Paint.Align.CENTER,310);
  text(canvas,paint,value(ct,cl),300,270,39,0xffe9f0fc,true,Paint.Align.CENTER,310);
  text(canvas,paint,"Personal · exterior",28,328,22,0xffe9f0fc,false,Paint.Align.LEFT,260);
  text(canvas,paint,"Claro · interior",572,328,22,0xffe9f0fc,false,Paint.Align.RIGHT,260);
  text(canvas,paint,summary(pt,pl),28,362,22,0xffa5b7d0,false,Paint.Align.LEFT,260);
  text(canvas,paint,summary(ct,cl),572,362,22,0xffa5b7d0,false,Paint.Align.RIGHT,260);
  return bitmap;
 }
 static void arc(Canvas canvas,Paint paint,float radius,float width,double ratio) {
  RectF rect=new RectF(300-radius,286-radius,300+radius,286+radius);
  paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(width);paint.setStrokeCap(Paint.Cap.ROUND);
  paint.setColor(0xff35445b);canvas.drawArc(rect,180,180,false,paint);
  if(Double.isFinite(ratio)&&ratio>0) {
   SweepGradient gradient=new SweepGradient(300,286,
    new int[]{0xfff45b69,0xffff913e,0xffffd34d,0xff4ce5a2,0xff4ce5a2},
    new float[]{0,.17f,.33f,.5f,1});
   Matrix matrix=new Matrix();matrix.setRotate(180,300,286);gradient.setLocalMatrix(matrix);
   paint.setShader(gradient);canvas.drawArc(rect,180,(float)(180*ratio),false,paint);paint.setShader(null);
  }
 }
 static void text(Canvas canvas,Paint paint,String text,float x,float y,float size,int color,
  boolean bold,Paint.Align align,float maxWidth) {
  paint.setStyle(Paint.Style.FILL);paint.setColor(color);paint.setTextAlign(align);
  paint.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));paint.setTextSize(size);
  while(paint.measureText(text)>maxWidth&&paint.getTextSize()>18)paint.setTextSize(paint.getTextSize()-1);
  canvas.drawText(text,x,y,paint);
 }
}
