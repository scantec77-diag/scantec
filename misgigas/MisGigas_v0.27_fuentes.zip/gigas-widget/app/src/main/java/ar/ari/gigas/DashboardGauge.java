package ar.ari.gigas;
import android.graphics.*;import java.util.Locale;
final class DashboardGauge {
 static Bitmap draw(String label,String value,String sub,double ratio){
 Bitmap b=Bitmap.createBitmap(480,310,Bitmap.Config.ARGB_8888);b.setDensity(Bitmap.DENSITY_NONE);Canvas c=new Canvas(b);Paint p=new Paint(3);RectF r=new RectF(40,52,440,452);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(22);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(0xff35445b);c.drawArc(r,180,180,false,p);
 if(Double.isFinite(ratio)){int[] colors={0xfff45b69,0xffff913e,0xffffd34d,0xff4ce5a2,0xff4ce5a2};float[] stops={0,.17f,.33f,.5f,1};SweepGradient g=new SweepGradient(240,252,colors,stops);Matrix m=new Matrix();m.setRotate(180,240,252);g.setLocalMatrix(m);p.setShader(g);c.drawArc(r,180,(float)(180*Math.max(0,Math.min(1,ratio))),false,p);p.setShader(null);}
 p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setColor(0xffa5b7d0);p.setTextSize(25);c.drawText(label,240,29,p);p.setColor(0xffe9f0fc);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(49);while(p.measureText(value)>350)p.setTextSize(p.getTextSize()-1);c.drawText(value,240,209,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(23);while(p.measureText(sub)>450)p.setTextSize(p.getTextSize()-1);c.drawText(sub,240,290,p);return b;
 }
 static String chargeText(BatterySnapshot.Snapshot b){
  return Double.isFinite(b.chargingWatts)?BatterySnapshot.num(b.chargingWatts,"W"):"Sin lectura de potencia";
 }
 static Bitmap battery(BatterySnapshot.Snapshot b){
  return draw("BATERÍA",b.percent>=0?b.percent+" %":"—",b.connected?chargeText(b):b.state,b.percent>=0?b.percent/100.0:Double.NaN);
 }
 static Bitmap charge(BatterySnapshot.Snapshot b){
  String value=Double.isFinite(b.chargingWatts)?BatterySnapshot.num(b.chargingWatts,"W"):"—";
  String sub=!b.connected?"Desconectado · 0–45 W":!Double.isFinite(b.chargingWatts)?"Sin lectura · 0–45 W":"Neta estimada · 0–45 W";
  return draw("POTENCIA DE CARGA",value,sub,ChargePower.ratio(b.chargingWatts));
 }
 static Bitmap plan(android.content.Context c,String key,String name){android.content.SharedPreferences p=Plan.prefs(c);float t=p.getFloat(key+"total",0),l=p.getFloat(key+"left",-1);boolean ok=Float.isFinite(t)&&Float.isFinite(l)&&t>0&&l>=0&&l<=t;return draw(name,ok?String.format(Locale.getDefault(),"%.2f GB",l):"—",ok?String.format(Locale.getDefault(),"restantes de %.2f GB",t):"Sin lectura",ok?l/t:Double.NaN);}
 static Bitmap network(android.content.Context c,String key,String name){android.content.SharedPreferences p=Plan.prefs(c);double gb=p.getLong(key,-1)/1e9;if(gb<0)return draw(name,"—","Sin lectura disponible",Double.NaN);double base=Math.pow(10,Math.floor(Math.log10(Math.max(.1,gb))));double n=gb/base,top=(n<=1?1:n<=2?2:n<=5?5:10)*base;return draw(name,String.format(Locale.getDefault(),"%.3f GB",gb),String.format(Locale.getDefault(),"Hoy · escala auto 0–%.1f GB",top),gb/top);}
}
