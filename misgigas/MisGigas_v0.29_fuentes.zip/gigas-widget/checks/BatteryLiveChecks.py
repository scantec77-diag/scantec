"""Regression: power events must override a stale sticky reading immediately.
Runs production battery code with a small fake Android boundary, not Android hardware.
"""
from pathlib import Path
import subprocess, tempfile
root=Path(__file__).resolve().parents[1]
files={
'android/content/Intent.java': '''package android.content;import java.util.*;public class Intent {
 public static final String ACTION_BATTERY_CHANGED="battery",ACTION_POWER_CONNECTED="connected",ACTION_POWER_DISCONNECTED="disconnected";
 private String action;private Map<String,Integer> extras=new HashMap<>();
 public Intent(String a){action=a;}public String getAction(){return action;}public Intent putExtra(String k,int v){extras.put(k,v);return this;}public int getIntExtra(String k,int fallback){return extras.getOrDefault(k,fallback);}
}''',
'android/content/IntentFilter.java': '''package android.content;import java.util.*;public class IntentFilter {public Set<String> actions=new HashSet<>();public IntentFilter(String s){actions.add(s);}public void addAction(String s){actions.add(s);}}''',
'android/content/Context.java': '''package android.content;public abstract class Context {public abstract Intent registerReceiver(Object receiver,IntentFilter f);public abstract <T>T getSystemService(Class<T> type);}''',
'android/os/BatteryManager.java': '''package android.os;public class BatteryManager {
 public static final String EXTRA_LEVEL="level",EXTRA_SCALE="scale",EXTRA_STATUS="status",EXTRA_PLUGGED="plugged",EXTRA_VOLTAGE="voltage",ACTION_CHARGING="charging",ACTION_DISCHARGING="discharging";
 public static final int BATTERY_STATUS_UNKNOWN=1,BATTERY_STATUS_CHARGING=2,BATTERY_STATUS_DISCHARGING=3,BATTERY_STATUS_FULL=5,BATTERY_PROPERTY_CURRENT_NOW=2;
 public int current=5000000,calls=0;public long remaining=1800000;public int getIntProperty(int p){calls++;return current;}public long computeChargeTimeRemaining(){return remaining;}
}''',
'ar/ari/gigas/BatteryLiveChecks.java': '''package ar.ari.gigas;import android.content.*;import android.os.*;
public class BatteryLiveChecks {
 static class Device extends Context {Intent sticky;BatteryManager manager=new BatteryManager();public Intent registerReceiver(Object r,IntentFilter f){return sticky;}public <T>T getSystemService(Class<T> c){return c.cast(manager);}}
 static Intent reading(int plugged,int state){return new Intent(Intent.ACTION_BATTERY_CHANGED).putExtra("plugged",plugged).putExtra("status",state).putExtra("level",76).putExtra("scale",100).putExtra("voltage",4500);}
 static void yes(boolean value,String why){if(!value)throw new AssertionError(why);}
 public static void main(String[] args){
  Device d=new Device();d.sticky=reading(0,3);
  BatterySnapshot.Snapshot s=BatterySnapshot.read(d);yes(!s.connected,"initial unplugged");
  s=BatterySnapshot.read(d,new Intent(Intent.ACTION_POWER_CONNECTED));yes(s.connected,"show charger immediately despite stale disconnected sticky");yes(Double.isNaN(s.chargingWatts)&&s.chargeTimeMillis==-1,"no invented power or estimate before fresh data");
  Intent fresh=reading(2,2);s=BatterySnapshot.read(d,fresh);yes(s.connected&&s.percent==76,"fresh battery broadcast is used directly");yes(s.chargingWatts==22.5&&s.chargeTimeMillis==1800000,"fresh power and time");
  d.sticky=fresh;int calls=d.manager.calls;s=BatterySnapshot.read(d,new Intent(Intent.ACTION_POWER_DISCONNECTED));yes(!s.connected,"hide charger immediately despite stale connected sticky");yes(s.chargeTimeMillis==-1&&Double.isNaN(s.chargingWatts)&&d.manager.calls==calls,"unplug does not keep old power or query charging metrics");
  d.sticky=reading(2,5);s=BatterySnapshot.read(d);yes(s.full&&ChargeTime.text(s.connected,s.full,s.chargeTimeMillis).equals("Carga completa"),"full charging status");
  d.manager.current=Integer.MIN_VALUE;d.manager.remaining=-1;d.sticky=fresh;s=BatterySnapshot.read(d);yes(Double.isNaN(s.chargingWatts)&&s.chargeTimeMillis==-1,"unsupported system readings");
  d.sticky=null;s=BatterySnapshot.read(d,new Intent(Intent.ACTION_POWER_CONNECTED));yes(s.connected&&s.percent==-1,"connect without any sticky data");s=BatterySnapshot.read(d);yes(!s.connected&&s.percent==-1,"missing reading");
  d.sticky=reading(2,2).putExtra("scale",0);yes(BatterySnapshot.read(d).percent==-1,"invalid percentage denominator");
  for(boolean widget:new boolean[]{false,true})for(boolean screen:new boolean[]{false,true})for(boolean connected:new boolean[]{false,true}){long delay=LiveRefreshPolicy.delay(widget,screen,connected);yes(delay==(!widget||!screen?-1:connected?1000:5000),"screen/widget polling policy");}
  IntentFilter f=BatteryEvents.filter();yes(f.actions.contains(Intent.ACTION_POWER_CONNECTED)&&f.actions.contains(Intent.ACTION_POWER_DISCONNECTED)&&f.actions.contains(Intent.ACTION_BATTERY_CHANGED),"both power transitions subscribed");
  System.out.println("PASS: stale sticky connect/unplug, fresh broadcast, full/missing/invalid readings and screen-off polling");
 }
}'''
}
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)
 for name,text in files.items():
  f=p/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(text)
 production=[root/'app/src/main/java/ar/ari/gigas'/f'{n}.java' for n in ['BatterySnapshot','BatteryEvents','ChargePower','ChargeTime','LiveRefreshPolicy']]
 subprocess.run(['java','com.sun.tools.javac.Main','-d',str(p/'classes'),*[str(p/n) for n in files],*map(str,production)],check=True)
 subprocess.run(['java','-cp',str(p/'classes'),'ar.ari.gigas.BatteryLiveChecks'],check=True)
