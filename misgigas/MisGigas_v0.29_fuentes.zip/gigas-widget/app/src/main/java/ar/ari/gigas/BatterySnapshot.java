package ar.ari.gigas;
import android.content.*;
import android.os.*;
import java.util.Locale;
/** Only the battery readings displayed by the dashboard; no per-tick sysfs scans. */
final class BatterySnapshot {
 static class Snapshot {String title="",details="",state="";double chargingWatts=Double.NaN;boolean connected=false,full=false;long chargeTimeMillis=-1;int percent=-1;}
 static String num(double n,String unit){return String.format(new Locale("es","AR"),"%.1f %s",n,unit);}
 static Snapshot read(Context c){return read(c,null);}
 static Snapshot read(Context c,Intent event){
  Snapshot s=new Snapshot();
  Intent battery=event!=null&&Intent.ACTION_BATTERY_CHANGED.equals(event.getAction())?event:c.registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
  Boolean hint=BatteryEvents.connectionHint(event);
  if(battery==null){if(hint!=null)s.connected=hint;s.state=s.connected?"Conectada · consultando…":"Sin lectura";s.title=s.state;return s;}
  int level=battery.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),scale=battery.getIntExtra(BatteryManager.EXTRA_SCALE,100);
  s.percent=level>=0&&scale>0?Math.max(0,Math.min(100,Math.round(100f*level/scale))):-1;
  int plugged=battery.getIntExtra(BatteryManager.EXTRA_PLUGGED,0),status=battery.getIntExtra(BatteryManager.EXTRA_STATUS,BatteryManager.BATTERY_STATUS_UNKNOWN);
  boolean fresh=(hint==null||hint==(plugged!=0));s.connected=hint!=null?hint:plugged!=0;
  s.full=s.connected&&fresh&&status==BatteryManager.BATTERY_STATUS_FULL;
  s.state=s.full?"Completa":s.connected?(fresh&&status==BatteryManager.BATTERY_STATUS_CHARGING?"Cargando":"Conectada · esperando carga"):"En uso";
  s.title=(s.percent>=0?s.percent+" %":"—")+" · "+s.state;
  BatteryManager manager=c.getSystemService(BatteryManager.class);
  if(manager!=null&&s.connected&&fresh){
   int current=manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW),voltage=battery.getIntExtra(BatteryManager.EXTRA_VOLTAGE,-1);
   s.chargingWatts=ChargePower.watts(plugged,voltage,current);
   if(!s.full)try{s.chargeTimeMillis=manager.computeChargeTimeRemaining();}catch(RuntimeException ignored){}
  }
  return s;
 }
}
