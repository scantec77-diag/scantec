package ar.ari.gigas;
/** No wake lock and no polling when the screen is off or no dashboard widget remains. */
final class LiveRefreshPolicy {
 static final long CHARGING_MS=1000,IDLE_MS=5000;
 static long delay(boolean widget,boolean screen,boolean connected){return !widget||!screen?-1:connected?CHARGING_MS:IDLE_MS;}
}
