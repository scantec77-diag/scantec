package ar.ari.gigas;
import android.content.*;
public class UpdateWakeReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){String a=i.getAction();if(Intent.ACTION_BOOT_COMPLETED.equals(a)||Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)){BatteryLiveService.startIfNeeded(c);DashboardWidget.request(c);UpdateJobs.checkSoon(c);ClaroJobs.ensure(c);PersonalJobs.ensure(c);GigasWidget.refresh(c);}}
}
