package ar.ari.gigas;
import android.content.*;
import android.os.BatteryManager;
/** Shared dynamic subscription: power events change visibility before the sticky data catches up. */
final class BatteryEvents {
 static IntentFilter filter(){IntentFilter f=new IntentFilter(Intent.ACTION_BATTERY_CHANGED);f.addAction(Intent.ACTION_POWER_CONNECTED);f.addAction(Intent.ACTION_POWER_DISCONNECTED);f.addAction(BatteryManager.ACTION_CHARGING);f.addAction(BatteryManager.ACTION_DISCHARGING);return f;}
 static Boolean connectionHint(Intent i){if(i==null)return null;if(Intent.ACTION_POWER_CONNECTED.equals(i.getAction()))return true;if(Intent.ACTION_POWER_DISCONNECTED.equals(i.getAction()))return false;return null;}
}
