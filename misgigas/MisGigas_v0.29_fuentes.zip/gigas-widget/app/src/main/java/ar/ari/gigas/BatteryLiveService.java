package ar.ari.gigas;
import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;
import android.util.Log;
/** User-visible live battery monitor for the home-screen dashboard, without network polling. */
public class BatteryLiveService extends Service {
 static final String CHANNEL="dashboard_live",STOP="ar.ari.gigas.LIVE_STOP";static volatile boolean running=false;
 private final Handler handler=new Handler(Looper.getMainLooper());private boolean subscribed=false,foreground=false;private String last="";
 private final Runnable tick=()->refresh(null,false);
 private final BroadcastReceiver events=new BroadcastReceiver(){public void onReceive(Context c,Intent i){String a=i.getAction();if(Intent.ACTION_SCREEN_OFF.equals(a)){handler.removeCallbacks(tick);return;}refresh(i,true);}};
 static boolean enabled(Context c){return Plan.prefs(c).getBoolean("liveBatteryEnabled",true);}
 static void startIfNeeded(Context c){
  if(!enabled(c)||DashboardWidget.ids(c).length==0)return;
  try{c.startForegroundService(new Intent(c,BatteryLiveService.class));}
  catch(RuntimeException e){Log.w("MisGigas-live","Could not start live monitor",e);Plan.prefs(c).edit().putString("liveBatteryError",e.getClass().getSimpleName()).apply();}
 }
 static void disable(Context c){Plan.prefs(c).edit().putBoolean("liveBatteryEnabled",false).apply();c.stopService(new Intent(c,BatteryLiveService.class));}
 public void onCreate(){
  super.onCreate();
  NotificationManager n=getSystemService(NotificationManager.class);NotificationChannel channel=new NotificationChannel(CHANNEL,"Tablero en vivo",NotificationManager.IMPORTANCE_LOW);channel.setDescription("Detección del cargador y batería del widget");channel.setShowBadge(false);n.createNotificationChannel(channel);
  PendingIntent open=PendingIntent.getActivity(this,90,new Intent(this,DashboardActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  PendingIntent pause=PendingIntent.getService(this,91,new Intent(this,BatteryLiveService.class).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification notice=new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_refresh).setContentTitle("Mis Gigas · tablero en vivo").setContentText("Detectando cargador y batería automáticamente").setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_SERVICE).addAction(new Notification.Action.Builder(null,"Pausar",pause).build()).build();
  try{if(Build.VERSION.SDK_INT>=34)startForeground(290,notice,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);else startForeground(290,notice);foreground=true;running=true;Plan.prefs(this).edit().remove("liveBatteryError").apply();}
  catch(RuntimeException e){Log.w("MisGigas-live","Could not enter foreground",e);Plan.prefs(this).edit().putString("liveBatteryError",e.getClass().getSimpleName()).apply();stopSelf();return;}
  IntentFilter filter=BatteryEvents.filter();filter.addAction(Intent.ACTION_SCREEN_ON);filter.addAction(Intent.ACTION_SCREEN_OFF);
  registerReceiver(events,filter);subscribed=true;
 }
 public int onStartCommand(Intent i,int flags,int id){
  if(i!=null&&STOP.equals(i.getAction())){Plan.prefs(this).edit().putBoolean("liveBatteryEnabled",false).apply();stopSelf();return START_NOT_STICKY;}
  if(!foreground||!enabled(this)||DashboardWidget.ids(this).length==0){stopSelf();return START_NOT_STICKY;}
  refresh(null,true);return START_STICKY;
 }
 private void refresh(Intent event,boolean force){
  handler.removeCallbacks(tick);
  if(!enabled(this)||DashboardWidget.ids(this).length==0){stopSelf();return;}
  BatterySnapshot.Snapshot s=BatterySnapshot.read(this,event);
  String signature=s.percent+"|"+s.connected+"|"+s.state+"|"+DashboardGauge.chargeText(s)+"|"+ChargeTime.text(s.connected,s.full,s.chargeTimeMillis);
  if(force||!signature.equals(last)){DashboardWidget.paintBattery(this,s);last=signature;}
  PowerManager power=getSystemService(PowerManager.class);long delay=LiveRefreshPolicy.delay(true,power!=null&&power.isInteractive(),s.connected);
  if(delay>=0)handler.postDelayed(tick,delay);
 }
 public IBinder onBind(Intent intent){return null;}
 public void onDestroy(){handler.removeCallbacksAndMessages(null);if(subscribed)unregisterReceiver(events);running=false;if(foreground)stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
