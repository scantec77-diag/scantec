from pathlib import Path
import os, subprocess, zipfile
p=Path(__file__).resolve().parent
sdk=Path(os.environ['ANDROID_HOME']); tools=sdk/'build-tools/35.0.0'; jar=sdk/'platforms/android-35/android.jar'; b=p/'manual-build'
import shutil
if b.exists():shutil.rmtree(b)
for d in ['generated','classes','dex']:(b/d).mkdir(parents=True,exist_ok=True)
def run(*a):subprocess.run(list(map(str,a)),check=True)
manifest=(p/'app/src/main/AndroidManifest.xml').read_text().replace('<manifest ','<manifest package="ar.ari.gigas" ',1)
(b/'AndroidManifest.xml').write_text(manifest)
run(tools/'aapt2','compile','--dir',p/'app/src/main/res','-o',b/'resources.zip')
run(tools/'aapt2','link','-o',b/'unsigned.apk','-I',jar,'-A',p/'app/src/main/assets','--manifest',b/'AndroidManifest.xml','--java',b/'generated','--min-sdk-version','29','--target-sdk-version','35','--version-code','29','--version-name','0.29',b/'resources.zip')
files=list((p/'app/src/main/java').rglob('*.java'))+list((b/'generated').rglob('*.java'))
libs=list((p/'vendor').glob('*.jar')); cp=os.pathsep.join(map(str,[jar]+libs))
run('java','com.sun.tools.javac.Main','-source','17','-target','17','-classpath',cp,'-d',b/'classes',*files)
run(tools/'d8','--lib',jar,'--min-api','29','--output',b/'dex',*list((b/'classes').rglob('*.class')),*libs)
with zipfile.ZipFile(b/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:z.write(b/'dex/classes.dex','classes.dex')
run(tools/'zipalign','-f','-p','4',b/'unsigned.apk',b/'aligned.apk')
out=p.parent/'MisGigas_v0.29_pruebas.apk'
run(tools/'apksigner','sign','--ks',p/'dev-signing/debug.keystore','--ks-pass','pass:android','--key-pass','pass:android','--out',out,b/'aligned.apk')
run(tools/'apksigner','verify','--verbose',out)
