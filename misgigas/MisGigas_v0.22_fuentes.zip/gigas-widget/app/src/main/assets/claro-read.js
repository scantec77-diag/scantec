(function () {
  'use strict';
  const norm = s => (s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
  const text = norm(document.body ? document.body.innerText.slice(0, 150000) : '');
  const expected = window.__misGigasClaroLine || '';
  const visible = el => el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden' && getComputedStyle(el).display !== 'none';
  if (/qu[eé] servicio quer[eé]s consultar/i.test(text)) {
    const candidates = Array.from(document.querySelectorAll('button,a,[role="button"],ion-card,mat-card,div,span'))
      .filter(el => visible(el) && /^\s*(?:\+54\s*)?(?:\(?\d{2,4}\)?[ -]*)?\d[\d -]{6,13}\s*$/.test(el.innerText || '') && !Array.from(el.children).some(c => /\d{7}/.test((c.innerText || '').replace(/\D/g, ''))));
    const numbers = [...new Set(candidates.map(el => el.innerText.replace(/\D/g, '')))];
    const target = expected ? numbers.find(n => n === expected) : numbers.length === 1 ? numbers[0] : '';
    if (!target) return JSON.stringify({status:'choose'});
    const el = candidates.find(el => el.innerText.replace(/\D/g, '') === target);
    if (!el || window.__misGigasClaroClicked) return JSON.stringify({status:'wait'});
    window.__misGigasClaroClicked = true;
    (el.closest('button,a,[role="button"],ion-card,mat-card') || el).click();
    return JSON.stringify({status:'opening',line:target});
  }
  if (document.querySelector('input[type="password"]') || /inici[aá] sesi[oó]n|ingres[aá] (?:tu )?(?:contrase[nñ]a|c[oó]digo)/i.test(text)) return JSON.stringify({status:'login'});
  const pageLines = [...text.matchAll(/(?:l[ií]nea|celular|n[uú]mero)\s*:?\s*([0-9][0-9 ()-]{7,17})/gi)].map(m=>m[1].replace(/\D/g,''));
  const line = window.__misGigasClaroSelected || (pageLines.length === 1 ? pageLines[0] : '');
  if (!line || (expected && line !== expected) || pageLines.some(n=>n !== line)) return JSON.stringify({status:'unverified'});
  // Spanish number formatting: 1.234,50 = 1234.50. Mixed/ambiguous formats are refused.
  function number(s) {
    if (!/^\d+(?:\.\d{3})*(?:,\d{1,3})?$/.test(s) && !/^\d+\.\d{1,2}$/.test(s)) return NaN;
    return Number(s.includes(',') ? s.replace(/\./g,'').replace(',','.') : /^\d{1,3}(?:\.\d{3})+$/.test(s) ? s.replace(/\./g,'') : s);
  }
  const results=[];
  for (const el of Array.from(document.querySelectorAll('section,article,ion-card,mat-card,div'))) {
    if (!visible(el)) continue;
    const card=norm(el.innerText);
    if(card.length>500 || !/internet|datos|gigas|navega/i.test(card) || /oferta|compr[aá]|regalo|promoci[oó]n|redes sociales|whatsapp|youtube|consumidos?/i.test(card))continue;
    // Both remaining and total must be explicit in the same small data block.
    const pairs=[
      /([0-9][0-9.,]*)\s*(GB|MB)\s*(?:disponibles?|restantes?)\s*(?:de|\/)\s*([0-9][0-9.,]*)\s*(GB|MB)\b/gi,
      /(?:disponibles?|restantes?|te quedan)\s*:?\s*([0-9][0-9.,]*)\s*(GB|MB)\s*(?:de|\/|total\s*:?)\s*([0-9][0-9.,]*)\s*(GB|MB)\b/gi
    ];
    for(const pattern of pairs){let m;while((m=pattern.exec(card))){
      // MB conversion is deliberately unsupported until the portal's unit convention is verified.
      if(m[2].toUpperCase()!=='GB'||m[4].toUpperCase()!=='GB')continue;
      const left=number(m[1]),total=number(m[3]);if(Number.isFinite(left)&&Number.isFinite(total)&&left>=0&&total>0&&left<=total)results.push({left,total});
    }}
  }
  const unique=[...new Map(results.map(r=>[r.left+'|'+r.total,r])).values()];
  if(unique.length===1)return JSON.stringify({status:'balance',line,...unique[0]});
  return JSON.stringify({status:unique.length>1?'ambiguous':'unverified'});
})()
