(function(email,password,allowEmail,allowPassword,doSubmit){
'use strict';
if(typeof doSubmit==='undefined')doSubmit=true;
if(location.protocol!=='https:'||location.hostname!=='mipersonal.personal.com.ar'||window.top!==window.self)return 'unsupported';
const shown=e=>!!e&&e.getClientRects().length>0;
const visible=e=>shown(e)&&!e.disabled;
const text=(document.body?.innerText||'').toLowerCase();
if(/contraseña incorrecta|contrase[ñn]a no es correcta|credenciales inv[aá]lidas|demasiados intentos|usuario o contrase[ñn]a incorrect/.test(text))return 'blocked';
const inputs=Array.from(document.querySelectorAll('input')).filter(visible);
if(inputs.some(e=>e.autocomplete==='one-time-code'||/^(otp|verificationcode|verification_code|codigo|c[oó]digo)$/i.test(e.name||e.id||'')))return 'blocked';
if(Array.from(document.querySelectorAll('iframe[src*=captcha],.g-recaptcha,.h-captcha')).some(visible))return 'blocked';
const pw=inputs.filter(e=>e.type==='password');
const ids=inputs.filter(e=>['email','text','tel',''].includes(e.type)&&(e.type==='email'||['username','email'].includes(e.autocomplete)||/^(username|email|identifier|mail|correo|usuario)$/i.test(e.name||e.id||'')||/mail|correo electr[oó]nico/i.test((e.placeholder||'')+' '+(e.getAttribute?.('aria-label')||''))));
let field,value,step;
if(pw.length===1&&allowPassword){field=pw[0];value=password;step='password';}
else if(pw.length===0&&ids.length===1&&allowEmail){field=ids[0];value=email;step='email';}
else return 'waiting';
const form=field.form;if(!form)return 'unsupported';
const target=new URL(form.getAttribute('action')||location.href,location.href);
if(target.origin!==location.origin||!['','_self'].includes(form.target))return 'unsupported';
const buttons=Array.from(form.querySelectorAll('button,input[type=submit]')).filter(shown).filter(b=>/^(siguiente|continuar|ingresar|iniciar sesi[oó]n|entrar|acceder)$/i.test((b.innerText||b.value||'').trim()));
if(buttons.length!==1)return 'unsupported';
if(buttons[0].formAction&&new URL(buttons[0].formAction,location.href).origin!==location.origin)return 'unsupported';
const set=(e,v)=>{Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(e,v);e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));};
// Preview validates the exact form before the native code reserves a retry window.
if(!doSubmit)return step;
// Both fields may be present in a single supported form.
if(step==='password'&&ids.length===1)set(ids[0],email);
set(field,value);if(buttons[0].disabled)return 'waiting';buttons[0].click();return step;
})
