package ar.ari.gigas;
import android.app.job.*;import android.content.*;import android.os.Build;import android.net.*;
final class PersonalJobs {
 static final int PERIODIC=601,MANUAL=602;
 static boolean ensure(Context c){if(Plan.prefs(c).getString("personalLine","").isEmpty())return false;JobScheduler j=c.getSystemService(JobScheduler.class);if(j.getPendingJob(PERIODIC)!=null)return true;
  return j.schedule(new JobInfo.Builder(PERIODIC,new ComponentName(c,PersonalJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).setPeriodic(15*60*1000L,5*60*1000L).build())==JobScheduler.RESULT_SUCCESS;}
 static void now(Context c){
  if(Plan.prefs(c).getString("personalLine","").isEmpty()){PersonalStore.error(c,"Abrí Personal una vez para vincular tu línea");return;}
  if(PersonalStore.busy(c))return;
  ConnectivityManager cm=c.getSystemService(ConnectivityManager.class);NetworkCapabilities nc=cm.getNetworkCapabilities(cm.getActiveNetwork());
  if(nc==null||!nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)){PersonalStore.error(c,"Sin conexión. Se conserva el último saldo");return;}
  Plan.prefs(c).edit().putLong("personalBusy",System.currentTimeMillis()).putString("personalError","").putBoolean("personalQueued",true).apply();GigasWidget.refresh(c);
  JobScheduler scheduler=c.getSystemService(JobScheduler.class);
  JobInfo.Builder b=new JobInfo.Builder(MANUAL,new ComponentName(c,PersonalJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
  if(Build.VERSION.SDK_INT>=31)b.setExpedited(true);else b.setOverrideDeadline(0);
  int result=scheduler.schedule(b.build());
  if(result!=JobScheduler.RESULT_SUCCESS&&Build.VERSION.SDK_INT>=31)result=scheduler.schedule(new JobInfo.Builder(MANUAL,new ComponentName(c,PersonalJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setOverrideDeadline(0).build());
  if(result!=JobScheduler.RESULT_SUCCESS)PersonalStore.error(c,"No se pudo iniciar la consulta. Volvé a intentar");
 }
}
