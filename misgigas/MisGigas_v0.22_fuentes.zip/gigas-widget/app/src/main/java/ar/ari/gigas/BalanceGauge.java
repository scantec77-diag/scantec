package ar.ari.gigas;
import android.content.Context;import android.content.SharedPreferences;import android.graphics.*;import java.util.Locale;
final class BalanceGauge {
 static Bitmap draw(Context context,float total,float left,boolean configured,int width){return draw(context,total,left,configured,width,"Personal");}
 static Bitmap draw(Context context,float total,float left,boolean configured,int width,String carrier){
  SharedPreferences s=Plan.prefs(context);int red=s.getInt("styleRed",0xfff45b69),yellow=s.getInt("styleYellow",0xffffca45),green=s.getInt("styleGreen",0xff4ce5a2),text=s.getInt("styleText",0xffffffff);
  int orange=s.getInt("styleOrange",0xffff8c32);float orangeGb=s.getFloat("styleOrangeGb",5),yellowGb=s.getFloat("styleYellowGb",10),greenGb=s.getFloat("styleGreenGb",20);int accent=GaugeMath.color4(left,red,orange,yellow,green,orangeGb,yellowGb,greenGb);
  Bitmap bitmap=Bitmap.createBitmap(width,GaugeResolution.height(width),Bitmap.Config.ARGB_8888);bitmap.setDensity(Bitmap.DENSITY_NONE);Canvas c=new Canvas(bitmap);c.scale(width/520f,bitmap.getHeight()/290f);
  Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG|Paint.FILTER_BITMAP_FLAG);p.setDither(true);p.setHinting(Paint.HINTING_ON);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(19);p.setStrokeCap(Paint.Cap.ROUND);
  RectF ring=new RectF(66,30,454,418);p.setColor(0xff707070);c.drawArc(ring,180,180,false,p);float ratio=configured?GaugeMath.ratio(total,left):0;
  if(ratio>0){int[] colors=new int[182];float[] stops=new float[182];for(int i=0;i<=180;i++){colors[i]=GaugeMath.color4(total*i/180f,red,orange,yellow,green,orangeGb,yellowGb,greenGb);stops[i]=i/360f;}colors[181]=colors[180];stops[181]=1;SweepGradient gradient=new SweepGradient(260,224,colors,stops);Matrix matrix=new Matrix();matrix.setRotate(180,260,224);gradient.setLocalMatrix(matrix);p.setShader(gradient);c.drawArc(ring,180,180*ratio,false,p);p.setShader(null);}
  p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(78);p.setColor(text);
  c.drawText(configured?String.format(Locale.getDefault(),"%.1f",left):"—",260,171,p);p.setTextSize(25);c.drawText("GB RESTANTES",260,207,p);
  p.setTextSize(24);p.setColor(configured?accent:text);c.drawText(configured?String.format(Locale.getDefault(),"de %.1f GB del plan",total):"Conectá tu línea "+carrier,260,264,p);return bitmap;
 }
}
