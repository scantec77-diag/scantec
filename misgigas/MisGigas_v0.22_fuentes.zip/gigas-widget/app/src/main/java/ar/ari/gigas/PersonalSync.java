package ar.ari.gigas;
import android.content.*;import android.os.*;import android.webkit.*;import org.json.*;import java.util.*;
/** Short-lived WebView reusing this app's existing session; no password capture or JS bridge. */
final class PersonalSync {
 static PersonalSync current;
 final Context context;final Handler handler=new Handler(Looper.getMainLooper());final List<Runnable> callbacks=new ArrayList<>();
 WebView web;boolean ended=false,reading=false,emailSent=false,passwordSent=false,authReserved=false,loading=true;String loginScript="";String[] access;String lastError="No se pudo actualizar. Abrí Personal para revisar la sesión";
 static void request(Context c,Runnable done){if(current!=null){current.callbacks.add(done);return;}PersonalSync s=new PersonalSync(c.getApplicationContext());current=s;s.callbacks.add(done);s.start();}
 static void cancel(){if(current!=null)current.finish(false,"Consulta interrumpida; se conserva el último saldo");}
 PersonalSync(Context c){context=c;}
 static void settings(WebView w){WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setCacheMode(WebSettings.LOAD_NO_CACHE);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);s.setUserAgentString(s.getUserAgentString().replace("; wv", "").replace("Version/4.0 ", ""));s.setUseWideViewPort(true);s.setLoadWithOverviewMode(true);CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(w,true);}
 void start(){
  if(Plan.prefs(context).getString("personalLine","").isEmpty()){finish(false,"Abrí Personal una vez para vincular tu línea");return;}
  Plan.prefs(context).edit().putLong("personalBusy",System.currentTimeMillis()).putString("personalError","").putBoolean("personalQueued",false).apply();GigasWidget.refresh(context);
  try{access=PersonalAccess.load(context);if(access==null)lastError=PersonalAccess.unavailableReason(context);try(java.io.InputStream in=context.getAssets().open("personal-login.js")){java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1)bytes.write(buffer,0,n);loginScript=new String(bytes.toByteArray(),java.nio.charset.StandardCharsets.UTF_8);}web=new WebView(context);settings(web);web.measure(android.view.View.MeasureSpec.makeMeasureSpec(1080,android.view.View.MeasureSpec.EXACTLY),android.view.View.MeasureSpec.makeMeasureSpec(1920,android.view.View.MeasureSpec.EXACTLY));web.layout(0,0,1080,1920);web.setWebViewClient(new WebViewClient(){
   public void onPageStarted(WebView w,String url,android.graphics.Bitmap icon){loading=true;}
   public void onPageFinished(WebView w,String url){loading=false;}
   public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){return !"https".equals(r.getUrl().getScheme());}
   public void onReceivedError(WebView w,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())finish(false,"Sin conexión o portal no disponible. Se conserva el último saldo");}
   public void onReceivedHttpError(WebView w,WebResourceRequest r,WebResourceResponse e){if(r.isForMainFrame())finish(false,"Personal no respondió correctamente. Volvé a intentar");}
   public boolean onRenderProcessGone(WebView w,RenderProcessGoneDetail detail){finish(false,"El lector de Personal se detuvo. Volvé a intentar");return true;}
  });
  String url=access!=null?PersonalStore.START:Plan.prefs(context).getString("personalPortal",PersonalStore.START);web.loadUrl(PersonalStore.trusted(url)?url:PersonalStore.START);
  handler.postDelayed(this::poll,2500);handler.postDelayed(()->finish(false,lastError),75000);
  }catch(Exception e){finish(false,"No se pudo iniciar el lector de Personal");}
 }
 void poll(){if(ended)return;if(!loading&&!reading&&PersonalStore.trusted(web.getUrl())){reading=true;String url=web.getUrl();web.evaluateJavascript("document.body ? document.body.innerText.slice(0,150000) : ''",value->{reading=false;if(ended)return;
   if(!PersonalStore.trusted(web.getUrl())||!url.equals(web.getUrl()))return;
   try{Object decoded=new JSONTokener(value).nextValue();if(!(decoded instanceof String))return;PersonalBalance b=PersonalBalance.parse((String)decoded);PersonalStore.save(context,b,url,false);CookieManager.getInstance().flush();finish(true,"");}catch(Exception e){if(access!=null&&!authReserved)lastError=e instanceof IllegalArgumentException?e.getMessage():"No se pudo leer el saldo de Personal";tryLogin();}
  });}if(!ended)handler.postDelayed(this::poll,2500);}
 void tryLogin(){if(ended||access==null||loginScript.isEmpty())return;String url=web.getUrl();if(!"https://mipersonal.personal.com.ar".equals(origin(url))){lastError="Abrí Personal: el acceso automático no reconoce esta pantalla";return;}

 // Inspect without submitting. Waiting for a form must never disable saved access.
 String script=loginCode(false);
 reading=true;web.evaluateJavascript(script,value->{if(ended)return;reading=false;if(!url.equals(web.getUrl()))return;try{
 String result=(String)new JSONTokener(value).nextValue();
 if("blocked".equals(result)){blockLogin();return;}
 if("unsupported".equals(result)){lastError="Personal muestra un formulario no reconocido; abrí Mi Personal para revisarlo";return;}
 if(!"email".equals(result)&&!"password".equals(result))return;
 if(!authReserved){if(!PersonalAccess.reserve(context)){lastError="El ingreso de Personal se reintentará tras la pausa de 15 minutos; se conserva el saldo";access=null;return;}authReserved=true;}
 reading=true;web.evaluateJavascript(loginCode(true),submitted->{reading=false;if(ended)return;try{String step=(String)new JSONTokener(submitted).nextValue();
 if("email".equals(step)){emailSent=true;lastError="Personal está completando el ingreso; si falla la conexión se reintentará en otra consulta";}
 else if("password".equals(step)){passwordSent=true;lastError="Personal no completó el ingreso; se reintentará en otra consulta";}
 else if("blocked".equals(step))blockLogin();
 else if("unsupported".equals(step))lastError="El formulario de Personal cambió; abrí Mi Personal para revisarlo";
 }catch(Exception e){lastError="No se pudo completar el ingreso; se reintentará en otra consulta";}});
 }catch(Exception e){lastError="No se pudo revisar el formulario de Personal";}});
 }
 String loginCode(boolean submit){return loginScript+"("+JSONObject.quote(access[0])+","+JSONObject.quote(access[1])+","+(!emailSent)+","+(!passwordSent)+","+submit+")";}
 void blockLogin(){PersonalAccess.pause(context);access=null;lastError="Personal requiere revisar el ingreso o validar un código. Abrí Mi Personal para continuar";}

 static String origin(String u){try{android.net.Uri x=android.net.Uri.parse(u);return x.getScheme()+"://"+x.getAuthority();}catch(Exception e){return "";}}
 void finish(boolean ok,String error){if(ended)return;ended=true;access=null;handler.removeCallbacksAndMessages(null);if(web!=null){web.stopLoading();web.destroy();web=null;}current=null;if(!ok){PersonalStore.error(context,error);}else GigasWidget.refresh(context);for(Runnable callback:new ArrayList<>(callbacks))callback.run();callbacks.clear();}
}
