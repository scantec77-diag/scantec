package ar.ari.gigas;
import android.app.job.*;import android.content.*;import android.os.Build;
final class ClaroJobs {
 static final int PERIODIC=701,MANUAL=702;
 static boolean ensure(Context c){if(!ClaroStore.linked(c))return false;JobScheduler j=c.getSystemService(JobScheduler.class);if(j.getPendingJob(PERIODIC)!=null)return true;return j.schedule(new JobInfo.Builder(PERIODIC,new ComponentName(c,ClaroJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).setPeriodic(15*60*1000L,5*60*1000L).build())==JobScheduler.RESULT_SUCCESS;}
 static void now(Context c){
  if(ClaroStore.busy(c))return;
  Plan.prefs(c).edit().putLong("claroBusy",System.currentTimeMillis()).putString("claroError","").apply();GigasWidget.refresh(c);
  JobScheduler j=c.getSystemService(JobScheduler.class);JobInfo.Builder b=new JobInfo.Builder(MANUAL,new ComponentName(c,ClaroJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY);
  if(Build.VERSION.SDK_INT>=31)b.setExpedited(true);else b.setOverrideDeadline(0);
  int result=j.schedule(b.build());
  if(result!=JobScheduler.RESULT_SUCCESS&&Build.VERSION.SDK_INT>=31)result=j.schedule(new JobInfo.Builder(MANUAL,new ComponentName(c,ClaroJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setOverrideDeadline(0).build());
  if(result!=JobScheduler.RESULT_SUCCESS)ClaroStore.error(c,"No se pudo iniciar la consulta; volvé a intentar");
 }
}
