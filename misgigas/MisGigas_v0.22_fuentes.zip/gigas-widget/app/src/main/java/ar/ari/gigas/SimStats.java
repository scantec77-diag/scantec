package ar.ari.gigas;
import android.content.*;import android.app.usage.*;import android.telephony.*;import android.net.*;import java.security.*;import org.json.*;
final class SimStats {
 static JSONObject read(Context c,int sub,long start) throws Exception {
  TelephonyManager t=c.getSystemService(TelephonyManager.class).createForSubscriptionId(sub);
  String id=t.getSubscriberId();if(id==null||id.isEmpty())throw new SecurityException("Identificador no disponible");
  NetworkStats.Bucket b=c.getSystemService(NetworkStatsManager.class).querySummaryForDevice(ConnectivityManager.TYPE_MOBILE,id,start,System.currentTimeMillis());if(b==null)throw new IllegalStateException("Sin estadísticas individuales");
  byte[] digest=MessageDigest.getInstance("SHA-256").digest(id.getBytes(java.nio.charset.StandardCharsets.UTF_8));StringBuilder fingerprint=new StringBuilder();for(byte v:digest)fingerprint.append(String.format(java.util.Locale.ROOT,"%02x",v&255));
  return new JSONObject().put("ok",true).put("sub",sub).put("identity",fingerprint.toString()).put("bytes",b.getRxBytes()+b.getTxBytes()).put("at",System.currentTimeMillis());
 }
 static double left(double initial,long baseline,long current){if(current<baseline)throw new IllegalArgumentException("Contador retrocedió");return Math.max(0,initial-(current-baseline)/1e9);}
}
