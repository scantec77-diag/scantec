package ar.ari.gigas;
import android.app.job.*;import java.util.*;
public class ClaroJobService extends JobService {
 final Set<JobParameters> active=new HashSet<>();
 public boolean onStartJob(JobParameters p){active.add(p);new android.os.Handler(getMainLooper()).post(()->{if(active.contains(p))ClaroSync.request(this,()->{if(active.remove(p))jobFinished(p,false);});});return true;}
 public boolean onStopJob(JobParameters p){active.remove(p);if(active.isEmpty())ClaroSync.cancel();return false;}
 public void onDestroy(){if(!active.isEmpty()){active.clear();ClaroSync.cancel();}super.onDestroy();}
}
