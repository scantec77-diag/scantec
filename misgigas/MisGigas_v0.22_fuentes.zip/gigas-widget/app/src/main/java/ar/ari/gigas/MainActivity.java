package ar.ari.gigas;
import android.app.*;import android.appwidget.AppWidgetManager;import android.app.usage.*;import android.content.*;import android.net.*;import android.os.*;import android.provider.Settings;import android.text.InputType;import android.widget.*;
import java.time.*;import java.util.*;
public class MainActivity extends Activity {
 LinearLayout body; TextView report; EditText cycle;TextView personalReport,claroReport;TextView updateBadge;Button updateButton;
 public void onCreate(Bundle state) { super.onCreate(state); ScrollView scroll=new ScrollView(this); body=new LinearLayout(this); body.setOrientation(1); body.setPadding(28,60,28,60); scroll.addView(body);setContentView(scroll);
 text("Mis Gigas · "+UpdateManager.versionName(this),24);updateRow();button("Guardar acceso automático de Personal",()->PersonalAccess.show(this));personalReport=text("",18);button("↻ Actualizar Personal ahora",()->{PersonalJobs.now(this);updatePersonal();});button("Abrir Mi Personal dentro de MisGigas",()->portal("personal"));text("Acceso directo al portal que probaste en Chrome. Iniciá sesión en Personal para ver tus gigas. No requiere aplicaciones auxiliares.",16);text("Personal: lectura automática, widget y consulta programada cada 15 minutos. Android puede demorarla. Abrí Personal una vez para vincular la línea. Claro: consulta en segundo plano cada 15 minutos aproximadamente, con sesión abierta.",16);
 plan("claro","Claro");plan("personal","Personal");
 button("↻ Actualizar Claro ahora",()->{ClaroJobs.now(this);Toast.makeText(this,"Consulta de Claro solicitada en segundo plano",1).show();}); button("Abrir Mi Claro / iniciar sesión",()->portal("claro")); button("Consultar cuenta Personal (prueba)",()->portal("personal"));
 button("Prueba opcional de consumo individual",()->startActivity(new Intent(this,SimTestActivity.class)));text("Consumo móvil medido por Android · ambas SIM juntas",20);text("El período es independiente de los planes. No representa el saldo oficial. GB decimales.",15);
 cycle=input("Día de inicio del período (1–31)","1",false);
 button("Permitir acceso al uso",()->startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)));
 button("Consultar consumo por aplicación",()->load()); report=text("Consultá después de habilitar el acceso al uso.",16);
 button("Agregar widget Claro",()->{AppWidgetManager m=AppWidgetManager.getInstance(this);if(m.isRequestPinAppWidgetSupported())m.requestPinAppWidget(new ComponentName(this,ClaroWidget.class),null,null);else Toast.makeText(this,"Buscá MisGigas · Claro en Widgets del inicio",1).show();});
 button("Agregar widget Personal",()->{AppWidgetManager m=AppWidgetManager.getInstance(this);if(m.isRequestPinAppWidgetSupported())m.requestPinAppWidget(new ComponentName(this,GigasFlexibleWidget.class),null,null);else Toast.makeText(this,"Agregalo desde el menú Widgets del inicio",1).show();});
 }
 final Handler dashboard=new Handler(Looper.getMainLooper());
 final Runnable repaint=new Runnable(){public void run(){updatePersonal();dashboard.postDelayed(this,2000);}};
 void updateRow(){
 LinearLayout row=new LinearLayout(this);row.setGravity(android.view.Gravity.CENTER_VERTICAL);body.addView(row);
 updateButton=new Button(this);updateButton.setText("Buscar actualización de MisGigas");row.addView(updateButton,new LinearLayout.LayoutParams(0,-2,1));
 updateBadge=new TextView(this);updateBadge.setText("1");updateBadge.setTextColor(0xffffffff);updateBadge.setTextSize(16);updateBadge.setTypeface(null,android.graphics.Typeface.BOLD);updateBadge.setGravity(android.view.Gravity.CENTER);updateBadge.setBackgroundResource(R.drawable.update_badge);int size=(int)(28*getResources().getDisplayMetrics().density);row.addView(updateBadge,new LinearLayout.LayoutParams(size,size));updateBadge.setContentDescription("Hay una actualización disponible");
 android.view.View.OnClickListener open=v->startActivity(new Intent(this,UpdateActivity.class));updateButton.setOnClickListener(open);updateBadge.setOnClickListener(open);updateIndicator();
 }
 void updateIndicator(){if(updateBadge!=null){boolean available=UpdateManager.hasUpdate(this);updateBadge.setVisibility(available?android.view.View.VISIBLE:android.view.View.GONE);updateButton.setText(available?"Actualizar MisGigas · "+Plan.prefs(this).getString("updateName",""):"Buscar actualización de MisGigas");}}
 void updatePersonal(){updateIndicator();if(claroReport!=null)claroReport.setText(Plan.text(this,"claro","Claro")+"\n"+ClaroWidget.compactStatus(this));if(personalReport!=null)personalReport.setText(Plan.text(this,"personal","Personal")+"\n"+GigasWidget.status(this)+"\n"+PersonalAccess.summary(this));}
 protected void onResume(){super.onResume();ClaroJobs.ensure(this);PersonalJobs.ensure(this);UpdateJobs.ensure(this);UpdateManager.checkAsync(this);dashboard.post(repaint);}
 protected void onPause(){dashboard.removeCallbacksAndMessages(null);super.onPause();}
 TextView text(String s,int size) { TextView t=new TextView(this); t.setText(s);t.setTextSize(size);t.setPadding(0,12,0,12);body.addView(t);return t; }
 EditText input(String hint,String value,boolean decimal) { EditText e=new EditText(this);e.setHint(hint);e.setInputType(InputType.TYPE_CLASS_NUMBER|(decimal?InputType.TYPE_NUMBER_FLAG_DECIMAL:0));e.setText(value);body.addView(e);return e; }
 void button(String label,Runnable r) { Button b=new Button(this);b.setText(label);body.addView(b);b.setOnClickListener(v->r.run()); }
 void portal(String key) { startActivity(new Intent(this,PortalActivity.class).putExtra("carrier",key)); }
 void open(String url) { try {startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));} catch(ActivityNotFoundException e){Toast.makeText(this,"No hay navegador disponible",1).show();} }
 void plan(String key,String name) { text(name,22); android.content.SharedPreferences p=Plan.prefs(this);
 EditText total=input("GB del plan",p.contains(key+"total")?""+p.getFloat(key+"total",0):"",true);
 EditText left=input("GB restantes informados por la compañía",p.contains(key+"left")?""+p.getFloat(key+"left",0):"",true);
 EditText day=input("Día de renovación",p.contains(key+"day")?""+p.getInt(key+"day",1):"",false);
 TextView status=text(Plan.text(this,key,name),15);if("claro".equals(key))claroReport=status;
 button("Guardar "+name,()->{try {float t=Float.parseFloat(total.getText().toString().replace(',','.')),l=Float.parseFloat(left.getText().toString().replace(',','.'));int d=Integer.parseInt(day.getText().toString());if(!Float.isFinite(t)||!Float.isFinite(l)||t<=0||l<0||l>t||d<1||d>31)throw new IllegalArgumentException();p.edit().putFloat(key+"total",t).putFloat(key+"left",l).putInt(key+"day",d).putString(key+"source","dato manual").putLong(key+"stamp",System.currentTimeMillis()).apply();status.setText(Plan.text(this,key,name));GigasWidget.refresh(this);}catch(Exception e){Toast.makeText(this,"Revisá GB totales, restantes y día (1–31)",1).show();}});
 }
 void load() { final int day;try {day=Integer.parseInt(cycle.getText().toString());if(day<1||day>31)throw new IllegalArgumentException();}catch(Exception e){report.setText("Ingresá un día entre 1 y 31");return;}
 AppOpsManager ops=(AppOpsManager)getSystemService(APP_OPS_SERVICE);if(ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,android.os.Process.myUid(),getPackageName())!=AppOpsManager.MODE_ALLOWED){report.setText("Habilitá el acceso al uso y volvé a consultar.");return;}
 report.setText("Leyendo estadísticas del teléfono…");new Thread(()->{String result;NetworkStats stats=null;try {
 long start=Plan.start(day).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();NetworkStatsManager m=(NetworkStatsManager)getSystemService(NETWORK_STATS_SERVICE);
 stats=m.querySummary(ConnectivityManager.TYPE_MOBILE,null,start,System.currentTimeMillis());if(stats==null)throw new IllegalStateException();Map<Integer,Long> totals=new HashMap<>();NetworkStats.Bucket bucket=new NetworkStats.Bucket();while(stats.hasNextBucket()){stats.getNextBucket(bucket);totals.merge(bucket.getUid(),bucket.getRxBytes()+bucket.getTxBytes(),Long::sum);}
 List<Map.Entry<Integer,Long>> rows=new ArrayList<>(totals.entrySet());rows.sort((a,b)->Long.compare(b.getValue(),a.getValue()));long sum=0;for(long bytes:totals.values())sum+=bytes;StringBuilder out=new StringBuilder(String.format(Locale.getDefault(),"Desde %s · ambas SIM\nTotal: %.3f GB\n",Plan.start(day),sum/1e9));
 for(Map.Entry<Integer,Long> row:rows){String label="Sistema / UID "+row.getKey();String[] packages=getPackageManager().getPackagesForUid(row.getKey());if(packages!=null&&packages.length>0){try{label=getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(packages[0],0)).toString();if(packages.length>1)label+=" (UID compartido)";}catch(Exception ignored){label=packages[0];}}out.append(String.format(Locale.getDefault(),"\n%s: %.3f GB",label,row.getValue()/1e9));}result=out.toString();
 }catch(Exception e){result="No se pudo consultar el consumo. Revisá el permiso de acceso al uso. Las estadísticas dependen del historial conservado por Android.";}finally{if(stats!=null)stats.close();}final String message=result;runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())report.setText(message);});}).start();
 }
}
