package ar.ari.gigas;
import android.content.*;
import android.net.Uri;
final class PersonalStore {
 static final String START="https://mipersonal.personal.com.ar/";
 static boolean trusted(String url){try{Uri u=Uri.parse(url);String h=u.getHost();return "https".equals(u.getScheme())&&h!=null&&(h.equals("personal.com.ar")||h.endsWith(".personal.com.ar"));}catch(Exception e){return false;}}
 static void save(Context c,PersonalBalance b,String url,boolean allowBind){
  if(!trusted(url))throw new IllegalArgumentException("El saldo no proviene del portal de Personal");
  SharedPreferences p=Plan.prefs(c);String line=p.getString("personalLine","");
  if(!b.line.equals(line)&&(!line.isEmpty()||!allowBind))throw new IllegalArgumentException("La línea no coincide. No se cambió el saldo guardado");
  // Store only a safe navigation URL (no query, tokens, or fragment).
  Uri u=Uri.parse(url);String path=u.getPath();String safe=new Uri.Builder().scheme("https").authority(u.getHost()).path(path==null?"/":path).build().toString();
  p.edit().putFloat("personaltotal",b.total).putFloat("personalleft",b.left).putString("personalLine",b.line)
   .putString("personalRenewal",b.renewal).putString("personalPortal",safe).putString("personalsource","Personal web")
   .putLong("personalstamp",System.currentTimeMillis()).putString("personalError","").putLong("personalBusy",0).putBoolean("personalQueued",false).apply();
  PersonalAccess.resume(c);PersonalJobs.ensure(c);GigasWidget.refresh(c);
 }
 static void error(Context c,String message){Plan.prefs(c).edit().putString("personalError",message).putLong("personalBusy",0).putBoolean("personalQueued",false).apply();GigasWidget.refresh(c);}
 static boolean busy(Context c){long t=Plan.prefs(c).getLong("personalBusy",0);return t>0&&System.currentTimeMillis()-t<120000;}
}
