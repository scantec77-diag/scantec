package ar.ari.gigas;
import android.content.*;import android.os.*;import android.webkit.*;import org.json.*;import java.util.*;
/** Runs on the main looper within a scheduled job; never launches an Activity. */
final class ClaroSync {
 static ClaroSync current;
 final Context context;final Handler handler=new Handler(Looper.getMainLooper());final List<Runnable> callbacks=new ArrayList<>();
 WebView web;boolean ended,reading,loading=true;String code="",selected="",error="No se identificó el saldo disponible y el total de Claro; se conserva el último dato";
 ClaroSync(Context c){context=c;}
 static void request(Context c,Runnable done){if(current!=null){current.callbacks.add(done);return;}ClaroSync s=new ClaroSync(c.getApplicationContext());current=s;s.callbacks.add(done);s.start();}
 static void cancel(){if(current!=null)current.finish(false,"Consulta interrumpida; se conserva el último saldo");}
 void start(){
  Plan.prefs(context).edit().putLong("claroBusy",System.currentTimeMillis()).putString("claroError","").apply();GigasWidget.refresh(context);
  try{code=ClaroStore.loadScript(context);web=new WebView(context);PersonalSync.settings(web);web.measure(android.view.View.MeasureSpec.makeMeasureSpec(1080,android.view.View.MeasureSpec.EXACTLY),android.view.View.MeasureSpec.makeMeasureSpec(1920,android.view.View.MeasureSpec.EXACTLY));web.layout(0,0,1080,1920);web.setWebViewClient(new WebViewClient(){
   public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){return !"https".equals(r.getUrl().getScheme());}
   public void onPageStarted(WebView w,String u,android.graphics.Bitmap icon){loading=true;}
   public void onPageFinished(WebView w,String u){loading=false;}
   public void onReceivedError(WebView w,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame())finish(false,"Sin conexión o portal Claro no disponible");}
   public void onReceivedHttpError(WebView w,WebResourceRequest r,WebResourceResponse e){if(r.isForMainFrame())finish(false,"Claro no respondió correctamente; se conserva el último saldo");}
   public boolean onRenderProcessGone(WebView w,RenderProcessGoneDetail d){finish(false,"El lector de Claro se detuvo; volvé a intentar");return true;}
  });web.loadUrl(ClaroStore.START);handler.postDelayed(this::poll,2000);handler.postDelayed(()->finish(false,error),90000);
  }catch(Exception e){finish(false,"No se pudo iniciar el lector de Claro");}
 }
 void poll(){if(ended)return;
  if(!loading&&!reading&&ClaroStore.trusted(web.getUrl())){reading=true;String url=web.getUrl();web.evaluateJavascript(ClaroStore.script(context,code,selected),value->{reading=false;if(ended||!ClaroStore.trusted(web.getUrl()))return;
   try{Object decoded=new JSONTokener(value).nextValue();if(!(decoded instanceof String))return;JSONObject r=new JSONObject((String)decoded);String status=r.optString("status");
    if("opening".equals(status)){String line=r.optString("line");if(!ClaroStore.bind(context,line,true)){finish(false,"La línea de Claro no coincide con la vinculada");return;}selected=line;}
    else if(!url.equals(web.getUrl()))return;
    else if("balance".equals(status)){if(!ClaroStore.bind(context,r.optString("line"),true))throw new IllegalArgumentException("La línea de Claro no coincide");ClaroStore.save(context,r,url);CookieManager.getInstance().flush();finish(true,"");}
    else if("login".equals(status))finish(false,"Sesión de Claro vencida; abrí Mi Claro desde la app para ingresar");
    else if("choose".equals(status))finish(false,"No se identificó una única línea; abrí Mi Claro desde la app");
    else if("ambiguous".equals(status))error="Claro muestra varios saldos; no se modificó el último dato";
   }catch(Exception e){error=e instanceof IllegalArgumentException?e.getMessage():"No se pudo validar el saldo de Claro";}
  });}if(!ended)handler.postDelayed(this::poll,2000);
 }
 void finish(boolean ok,String message){if(ended)return;ended=true;handler.removeCallbacksAndMessages(null);if(web!=null){web.stopLoading();web.destroy();web=null;}current=null;if(!ok)ClaroStore.error(context,message);else GigasWidget.refresh(context);for(Runnable callback:new ArrayList<>(callbacks))callback.run();callbacks.clear();}
}
