package ar.ari.gigas;
/** Fresh provider identity so launchers read the current resizing metadata. */
public class GigasFlexibleWidget extends GigasWidget {}
