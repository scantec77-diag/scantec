package ar.ari.gigas;
import android.content.*;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.Locale;
final class Plan {
 static SharedPreferences prefs(Context c) { return c.getSharedPreferences("plans",0); }
 static LocalDate boundary(YearMonth m,int day) { return m.atDay(Math.min(day,m.lengthOfMonth())); }
 static LocalDate start(int day) { LocalDate now=LocalDate.now(); YearMonth m=YearMonth.from(now); LocalDate s=boundary(m,day); return s.isAfter(now)?boundary(m.minusMonths(1),day):s; }
 static LocalDate next(int day) { LocalDate now=LocalDate.now(); YearMonth m=YearMonth.from(now); LocalDate n=boundary(m,day); return n.isAfter(now)?n:boundary(m.plusMonths(1),day); }
 static String text(Context c,String key,String label) {
 SharedPreferences p=prefs(c); if(!p.contains(key+"total"))return label+": sin configurar";
 float total=p.getFloat(key+"total",0),left=p.getFloat(key+"left",0); int day=p.getInt(key+"day",1);
 long stamp=p.getLong(key+"stamp",0); String date=java.text.DateFormat.getDateTimeInstance(3,3).format(new java.util.Date(stamp));
 if("personal".equals(key)){
 String renewal=p.getString("personalRenewal","");String dateLabel=renewal.isEmpty()?"":"\nRenueva: "+renewal;
 return String.format(Locale.getDefault(),"Personal · total %.2f GB\nRestantes %.2f GB\nConsumidos %.2f GB\n%.1f%% disponible\nÚltima lectura: %s%s",total,left,Math.max(0,total-left),total>0?100*left/total:0,date,dateLabel);
 }
 if("claro".equals(key)&&"lectura automática del portal".equals(p.getString("clarosource",""))&&!p.getBoolean("claroVerified",false))return "Claro: lectura anterior sin verificar. Tocá Actualizar Claro.\n"+p.getString("claroError","");
 return String.format(Locale.getDefault(),"%s: %.2f / %.2f GB · %.0f%% disponibles\n%d días a renovación · %s %s",label,left,total,total>0?100*left/total:0,ChronoUnit.DAYS.between(LocalDate.now(),next(day)),p.getString(key+"source","dato manual"),date);
 }
}
