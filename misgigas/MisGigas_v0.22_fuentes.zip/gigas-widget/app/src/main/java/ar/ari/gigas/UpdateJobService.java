package ar.ari.gigas;
import android.app.job.*;import java.util.*;
public class UpdateJobService extends JobService {
 final Set<JobParameters> active=new HashSet<>();
 public boolean onStartJob(JobParameters p){active.add(p);new Thread(()->{boolean failed=false;try{UpdateManager.check(this);}catch(Exception ignored){failed=true;}final boolean retry=failed;new android.os.Handler(getMainLooper()).post(()->{if(active.remove(p))jobFinished(p,retry);});},"MisGigas-update-job").start();return true;}
 public boolean onStopJob(JobParameters p){active.remove(p);return true;}
 public void onDestroy(){active.clear();super.onDestroy();}
}
