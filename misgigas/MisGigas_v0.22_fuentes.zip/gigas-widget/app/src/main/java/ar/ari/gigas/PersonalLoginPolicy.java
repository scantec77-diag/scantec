package ar.ari.gigas;
/** Persistent cooldown only after a recognized form is about to be submitted. */
final class PersonalLoginPolicy {
 static final long RETRY_DELAY=15*60*1000L;
 static boolean mayAttempt(boolean blocked,long retryAt,long now){return !blocked&&(retryAt<=now||retryAt-now>RETRY_DELAY);}
 static long retryAt(long now){return now+RETRY_DELAY;}
}
