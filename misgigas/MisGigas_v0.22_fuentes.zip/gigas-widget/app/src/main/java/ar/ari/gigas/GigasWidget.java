package ar.ari.gigas;
import android.app.*;import android.appwidget.*;import android.content.*;import android.widget.*;import java.util.*;
public class GigasWidget extends AppWidgetProvider {
 static final String UPDATE="ar.ari.gigas.REFRESH_PERSONAL";
 static String status(Context c){android.content.SharedPreferences p=Plan.prefs(c);
  if(PersonalStore.busy(c))return p.getBoolean("personalQueued",false)?"Consulta solicitada…":"Consultando Personal…";
  String error=p.getString("personalError","");if(!error.isEmpty())return "Pendiente: "+error;
  if(p.getString("personalLine","").isEmpty())return "Abrí Personal para vincular tu línea";
  return "Automático cada 15 min aprox. · ↻ consultar ahora";
 }
 public void onReceive(Context c,Intent i){super.onReceive(c,i);if(UPDATE.equals(i.getAction())){PersonalJobs.ensure(c);PersonalJobs.now(c);}}
 public void onEnabled(Context c){PersonalJobs.ensure(c);UpdateJobs.ensure(c);UpdateManager.checkAsync(c);}
 public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,android.os.Bundle options){onUpdate(c,m,new int[]{id});}
 static String compactStatus(Context c){android.content.SharedPreferences p=Plan.prefs(c);
  if(PersonalStore.busy(c))return p.getBoolean("personalQueued",false)?"Consulta solicitada…":"Actualizando…";
  if(!p.getString("personalError","").isEmpty())return "Sin actualizar · tocá para ver";
  long stamp=p.getLong("personalstamp",0);if(stamp==0)return "Tocá para conectar Personal";
  return "Actualizado · "+(android.text.format.DateUtils.isToday(stamp)?android.text.format.DateFormat.getTimeFormat(c).format(new java.util.Date(stamp)):android.text.format.DateFormat.format("dd/MM HH:mm",stamp));
 }
 public void onUpdate(Context c,AppWidgetManager m,int[] ids){
  if(ids.length==0)return;
  UpdateJobs.checkSoon(c);
  android.content.SharedPreferences p=Plan.prefs(c);float total=p.getFloat("personaltotal",0),left=p.getFloat("personalleft",0);
  boolean configured=p.contains("personaltotal")&&total>0&&Float.isFinite(total)&&Float.isFinite(left)&&left>=0&&left<=total;
  String description=configured?String.format(Locale.getDefault(),"Personal: %.1f GB disponibles de %.1f GB; %.0f por ciento restante. %s",left,total,100*left/total,compactStatus(c)):"Personal sin saldo configurado. Tocá para conectar";
  for(int id:ids){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);
   android.os.Bundle options=m.getAppWidgetOptions(id);
   int height=options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,220);
   int width=Math.max(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,320),options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH,320));
   android.util.DisplayMetrics metrics=c.getResources().getDisplayMetrics();
   android.graphics.Bitmap bitmap=BalanceGauge.draw(c,total,left,configured,GaugeResolution.width(width,height,metrics.density,metrics.widthPixels,metrics.heightPixels));
   v.setViewVisibility(R.id.header,height<160?android.view.View.GONE:android.view.View.VISIBLE);
   v.setViewVisibility(R.id.status,height<200?android.view.View.GONE:android.view.View.VISIBLE);
   v.setViewVisibility(R.id.update_badge,UpdateManager.hasUpdate(c)?android.view.View.VISIBLE:android.view.View.GONE);
   v.setOnClickPendingIntent(R.id.update_badge,PendingIntent.getActivity(c,8,new Intent(c,UpdateActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
   v.setTextViewText(R.id.app_update,UpdateManager.hasUpdate(c)?"Actualizar · "+p.getString("updateName",""):"Buscar actualización");
   v.setOnClickPendingIntent(R.id.app_update,PendingIntent.getActivity(c,8,new Intent(c,UpdateActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
   v.setImageViewBitmap(R.id.gauge,bitmap);v.setContentDescription(R.id.gauge,description);v.setTextViewText(R.id.status,compactStatus(c));
   PendingIntent panel=PendingIntent.getActivity(c,0,new Intent(c,DashboardActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   v.setOnClickPendingIntent(R.id.root,panel);v.setOnClickPendingIntent(R.id.gauge,panel);v.setOnClickPendingIntent(R.id.status,panel);
   v.setOnClickPendingIntent(R.id.refresh,PendingIntent.getBroadcast(c,2,new Intent(c,GigasWidget.class).setAction(UPDATE),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
   m.updateAppWidget(id,v);
  }
 }
 static void refresh(Context c){DashboardWidget.request(c);AppWidgetManager m=AppWidgetManager.getInstance(c);for(Class<?> provider:new Class<?>[]{GigasWidget.class,GigasFlexibleWidget.class})new GigasWidget().onUpdate(c,m,m.getAppWidgetIds(new ComponentName(c,provider)));new ClaroWidget().onUpdate(c,m,m.getAppWidgetIds(new ComponentName(c,ClaroWidget.class)));}
}
