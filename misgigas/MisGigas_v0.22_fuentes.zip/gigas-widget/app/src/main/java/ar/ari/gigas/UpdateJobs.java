package ar.ari.gigas;
import android.content.*;import android.app.job.*;
final class UpdateJobs {
 static final int PERIODIC=608,SOON=609;
 static void ensure(Context c){JobScheduler j=c.getSystemService(JobScheduler.class);JobInfo old=j.getPendingJob(PERIODIC);if(old==null||old.getIntervalMillis()!=15*60*1000L)j.schedule(new JobInfo.Builder(PERIODIC,new ComponentName(c,UpdateJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).setPeriodic(15*60*1000L).build());}
 static void checkSoon(Context c){ensure(c);if(System.currentTimeMillis()-Plan.prefs(c).getLong("updateChecked",0)<5*60*1000L)return;JobScheduler j=c.getSystemService(JobScheduler.class);if(j.getPendingJob(SOON)==null)j.schedule(new JobInfo.Builder(SOON,new ComponentName(c,UpdateJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setMinimumLatency(1000).setBackoffCriteria(30000,JobInfo.BACKOFF_POLICY_EXPONENTIAL).build());}
}
