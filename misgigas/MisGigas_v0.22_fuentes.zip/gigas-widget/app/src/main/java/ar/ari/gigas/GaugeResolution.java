package ar.ari.gigas;
/** Pixel sizing independent of Android so memory and resize limits can be checked. */
final class GaugeResolution {
 static int width(int widthDp,int heightDp,float density,int screenWidth,int screenHeight){
  double availableWidth=Math.max(1,widthDp-16)*density;
  int chrome=16+32+(heightDp>=160?44:0)+(heightDp>=200?20:0);
  double availableHeight=Math.max(1,heightDp-chrome)*density;
  double fit=Math.min(availableWidth,availableHeight*520.0/290.0);
  // Supersample curves and type; stay below the RemoteViews bitmap memory limit.
  double budget=Math.max(1,(double)screenWidth*screenHeight)*1.2;
  double maxWidth=Math.sqrt(budget*520.0/290.0);
  return Math.max(1,(int)Math.floor(Math.min(3840,Math.min(fit*2.0,maxWidth))));
 }
 static int height(int width){return Math.max(1,(int)Math.floor(width*290.0/520.0));}
}
