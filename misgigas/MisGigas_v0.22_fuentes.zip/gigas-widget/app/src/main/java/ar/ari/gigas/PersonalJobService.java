package ar.ari.gigas;
import android.app.job.*;import java.util.*;
public class PersonalJobService extends JobService {
 final Set<JobParameters> active=new HashSet<>();
 public boolean onStartJob(JobParameters p){active.add(p);new android.os.Handler(getMainLooper()).post(()->{if(active.contains(p))PersonalSync.request(this,()->{if(active.remove(p))jobFinished(p,false);});});return true;}
 public boolean onStopJob(JobParameters p){active.remove(p);if(active.isEmpty())PersonalSync.cancel();return false;}
 public void onDestroy(){if(!active.isEmpty()){active.clear();PersonalSync.cancel();}super.onDestroy();}
}
