package ar.ari.gigas;
import android.app.*;import android.appwidget.*;import android.content.*;import android.widget.*;import java.util.*;
public class ClaroWidget extends AppWidgetProvider {
 static final String UPDATE="ar.ari.gigas.REFRESH_CLARO";
 public void onReceive(Context c,Intent i){super.onReceive(c,i);if(UPDATE.equals(i.getAction())){ClaroJobs.ensure(c);ClaroJobs.now(c);}}
 static String compactStatus(Context c){if(ClaroStore.busy(c))return "Consultando Claro…";String error=Plan.prefs(c).getString("claroError","");if(!error.isEmpty())return error;if(!Plan.prefs(c).getBoolean("claroVerified",false))return "Saldo anterior sin verificar · ↻ consultar";long stamp=Plan.prefs(c).getLong("clarostamp",0);if(stamp==0)return "Tocá para importar el saldo de Claro";return "Última lectura · "+(android.text.format.DateUtils.isToday(stamp)?android.text.format.DateFormat.getTimeFormat(c).format(new java.util.Date(stamp)):android.text.format.DateFormat.format("dd/MM HH:mm",stamp));}
 public void onEnabled(Context c){ClaroJobs.ensure(c);UpdateJobs.ensure(c);UpdateManager.checkAsync(c);}
 public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,android.os.Bundle options){onUpdate(c,m,new int[]{id});}
 public void onUpdate(Context c,AppWidgetManager m,int[] ids){
  if(ids.length==0)return;ClaroJobs.ensure(c);
  UpdateJobs.checkSoon(c);
  android.content.SharedPreferences p=Plan.prefs(c);float total=p.getFloat("clarototal",0),left=p.getFloat("claroleft",0);
  boolean configured=!("lectura automática del portal".equals(p.getString("clarosource",""))&&!p.getBoolean("claroVerified",false))&&p.contains("clarototal")&&total>0&&Float.isFinite(total)&&Float.isFinite(left)&&left>=0&&left<=total;
  String description=configured?String.format(Locale.getDefault(),"Claro: %.1f GB disponibles de %.1f GB; %.0f por ciento restante. %s",left,total,100*left/total,compactStatus(c)):"Claro sin saldo configurado. Tocá para importar";
  for(int id:ids){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget);v.setTextViewText(R.id.carrier_name,"CLARO");
   android.os.Bundle options=m.getAppWidgetOptions(id);
   int height=options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,220);
   int width=Math.max(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH,320),options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH,320));
   android.util.DisplayMetrics metrics=c.getResources().getDisplayMetrics();
   android.graphics.Bitmap bitmap=BalanceGauge.draw(c,total,left,configured,GaugeResolution.width(width,height,metrics.density,metrics.widthPixels,metrics.heightPixels),"Claro");
   v.setViewVisibility(R.id.header,height<160?android.view.View.GONE:android.view.View.VISIBLE);
   v.setViewVisibility(R.id.status,height<200?android.view.View.GONE:android.view.View.VISIBLE);
   v.setViewVisibility(R.id.update_badge,UpdateManager.hasUpdate(c)?android.view.View.VISIBLE:android.view.View.GONE);
   v.setOnClickPendingIntent(R.id.update_badge,PendingIntent.getActivity(c,8,new Intent(c,UpdateActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
   v.setTextViewText(R.id.app_update,UpdateManager.hasUpdate(c)?"Actualizar · "+p.getString("updateName",""):"Buscar actualización");
   v.setOnClickPendingIntent(R.id.app_update,PendingIntent.getActivity(c,8,new Intent(c,UpdateActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
   v.setImageViewBitmap(R.id.gauge,bitmap);v.setContentDescription(R.id.gauge,description);v.setTextViewText(R.id.status,compactStatus(c));
   PendingIntent panel=PendingIntent.getActivity(c,20,new Intent(c,DashboardActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   v.setOnClickPendingIntent(R.id.root,panel);v.setOnClickPendingIntent(R.id.gauge,panel);v.setOnClickPendingIntent(R.id.status,panel);
   v.setContentDescription(R.id.refresh,"Actualizar Claro en segundo plano");v.setOnClickPendingIntent(R.id.refresh,PendingIntent.getBroadcast(c,21,new Intent(c,ClaroWidget.class).setAction(UPDATE),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
   m.updateAppWidget(id,v);
  }
 }
}
