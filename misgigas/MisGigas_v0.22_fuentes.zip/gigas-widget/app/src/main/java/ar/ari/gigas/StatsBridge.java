package ar.ari.gigas;
import android.os.*;import android.content.*;import org.json.*;
public class StatsBridge extends Binder {
 static final String DESCRIPTOR="ar.ari.gigas.SimStats";final Context context;final int owner;
 public StatsBridge() throws Exception {this(null);}
 public StatsBridge(Context ignored) throws Exception {
  Class<?> cls=Class.forName("android.app.ActivityThread");Object thread=cls.getMethod("currentActivityThread").invoke(null);if(thread==null)thread=cls.getMethod("systemMain").invoke(null);
  Context system=(Context)cls.getMethod("getSystemContext").invoke(thread);context=system.createPackageContext("com.android.shell",0);owner=context.getPackageManager().getApplicationInfo("ar.ari.gigas",0).uid;attachInterface(null,DESCRIPTOR);
 }
 protected boolean onTransact(int code,Parcel data,Parcel reply,int flags)throws RemoteException {
  if(code==INTERFACE_TRANSACTION){reply.writeString(DESCRIPTOR);return true;}
  if(Binder.getCallingUid()!=owner)throw new SecurityException("Cliente no autorizado");
  if(code==16777115){System.exit(0);return true;}
  if(code!=1)return super.onTransact(code,data,reply,flags);data.enforceInterface(DESCRIPTOR);int sub=data.readInt();long start=data.readLong();long identity=Binder.clearCallingIdentity();String result;
  try{result=SimStats.read(context,sub,start).toString();}catch(Throwable e){result="{\"ok\":false,\"error\":\""+e.getClass().getSimpleName()+"\"}";}finally{Binder.restoreCallingIdentity(identity);}
  reply.writeNoException();reply.writeString(result);return true;
 }
}
