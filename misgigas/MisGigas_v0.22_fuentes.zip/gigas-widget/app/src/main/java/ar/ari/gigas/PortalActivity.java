package ar.ari.gigas;
import android.app.*;import android.content.*;import android.net.Uri;import android.os.*;import android.webkit.*;import android.widget.*;import java.util.*;import java.util.regex.*;import org.json.*;
public class PortalActivity extends Activity {
 WebView web;TextView address;String carrier;boolean loading=true;
 final Handler auto=new Handler(Looper.getMainLooper());boolean active=false;int attempts=0;String claroScript="",claroSelected="";boolean claroSaved=false;
 public void onCreate(Bundle b){super.onCreate(b);carrier="claro".equals(getIntent().getStringExtra("carrier"))?"claro":"personal";
 LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(16,52,16,28);setContentView(root);
 address=new TextView(this);root.addView(address);
 TextView note=new TextView(this);note.setText("claro".equals(carrier)?"Claro · ingreso a tu cuenta. La flecha del widget consulta en segundo plano cada 15 min aprox.; Android puede demorarla.":"Personal · lectura automática y sincronización de prueba cada 15 min.");root.addView(note);
 LinearLayout buttons=new LinearLayout(this);root.addView(buttons);Button read=new Button(this);read.setText("claro".equals(carrier)?"Consultar":"Importar");buttons.addView(read,new LinearLayout.LayoutParams(0,-2,1));read.setOnClickListener(v->{if("claro".equals(carrier))startClaro();else extract();});Button reload=new Button(this);reload.setText("Recargar");buttons.addView(reload,new LinearLayout.LayoutParams(0,-2,1));reload.setOnClickListener(v->{claroSaved=false;attempts=0;web.reload();});Button external=new Button(this);external.setText("Chrome");buttons.addView(external,new LinearLayout.LayoutParams(0,-2,1));external.setOnClickListener(v->{String u=web.getUrl();if(u!=null)try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(ActivityNotFoundException e){}});
 web=new WebView(this);root.addView(web,new LinearLayout.LayoutParams(-1,0,1));WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);CookieManager.getInstance().setAcceptCookie(true);settings.setDomStorageEnabled(true);if("personal".equals(carrier))settings.setCacheMode(WebSettings.LOAD_NO_CACHE);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
 settings.setUseWideViewPort(true);settings.setLoadWithOverviewMode(true);
 settings.setUserAgentString(settings.getUserAgentString().replace("; wv", "").replace("Version/4.0 ", ""));
 settings.setSupportMultipleWindows(true);
 web.setWebChromeClient(new WebChromeClient(){
 public boolean onCreateWindow(WebView view,boolean dialog,boolean userGesture,Message result){
 if(!userGesture)return false;
 final WebView popup=new WebView(PortalActivity.this);
 popup.setWebViewClient(new WebViewClient(){
 boolean forward(String url){if(url!=null&&"https".equalsIgnoreCase(Uri.parse(url).getScheme())){web.loadUrl(url);popup.post(()->popup.destroy());return true;}return false;}
 public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){if(!r.isForMainFrame())return false;return forward(r.getUrl().toString());}
 public void onPageStarted(WebView w,String url,android.graphics.Bitmap icon){forward(url);}
 });
 ((WebView.WebViewTransport)result.obj).setWebView(popup);result.sendToTarget();return true;
 }
 });
 web.setWebViewClient(new WebViewClient(){public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest r){return !"https".equalsIgnoreCase(r.getUrl().getScheme());}public void onPageStarted(WebView w,String url,android.graphics.Bitmap icon){loading=true;address.setText(displayAddress(url));}public void onReceivedError(WebView w,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame()){loading=false;Toast.makeText(PortalActivity.this,"No se pudo cargar el portal. Probá Recargar o Navegador.",1).show();}}public void onPageFinished(WebView w,String url){loading=false;address.setText(displayAddress(url));CookieManager.getInstance().flush();if(active){auto.removeCallbacksAndMessages(null);if("personal".equals(carrier)){attempts=0;auto.postDelayed(PortalActivity.this::autoRead,1500);}else if(!claroSaved)auto.postDelayed(PortalActivity.this::autoClaro,1500);}}});
 try(java.io.InputStream in=getAssets().open("claro-read.js")){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);claroScript=new String(out.toByteArray(),java.nio.charset.StandardCharsets.UTF_8);}catch(Exception ignored){}
 if(b==null||web.restoreState(b)==null)web.loadUrl("claro".equals(carrier)?"https://miclaro.claro.com.ar/":"https://mipersonal.personal.com.ar/");
 }
 String displayAddress(String url){Uri u=Uri.parse(url);return "Acceso web · "+(u.getHost()==null?"":u.getHost());}
 boolean trusted(){String u=web.getUrl();if(u==null)return false;Uri uri=Uri.parse(u);String host=uri.getHost();String base="claro".equals(carrier)?"claro.com.ar":"personal.com.ar";return "https".equals(uri.getScheme())&&host!=null&&(host.equals(base)||host.endsWith("."+base));}
 void extract(){if("personal".equals(carrier)){readPersonal(true);return;}if(loading||!trusted()){Toast.makeText(this,"Esperá a que cargue el portal oficial de la compañía",1).show();return;}
 // Read visible text only, never inputs, passwords, cookies or tokens. No JS bridge.
 web.evaluateJavascript("(function(){return document.body?document.body.innerText.slice(0,150000):'';})()",value->{if(!trusted())return;try{Object decoded=new JSONTokener(value).nextValue();if(!(decoded instanceof String))throw new Exception();String text=(String)decoded;
 Pattern pattern=Pattern.compile("(?i)([0-9]+(?:[.,][0-9]+)?)\\s*(GB|gigas?)(?![a-z])");Matcher m=pattern.matcher(text);List<String> labels=new ArrayList<>();List<Float> numbers=new ArrayList<>();while(m.find()&&labels.size()<30){float n=Float.parseFloat(m.group(1).replace(',','.'));if(!Float.isFinite(n))continue;numbers.add(n);labels.add(text.substring(Math.max(0,m.start()-45),Math.min(text.length(),m.end()+45)).replace('\n',' '));}
 if(labels.isEmpty()){new AlertDialog.Builder(this).setMessage("No se encontraron valores en GB. Abrí el detalle de datos. Si el sitio impide el acceso, usá el navegador y cargá el saldo manualmente.").setPositiveButton("Aceptar",null).show();return;}
 new AlertDialog.Builder(this).setTitle("Elegí los GB RESTANTES de tu línea").setItems(labels.toArray(new String[0]),(d,index)->confirm(numbers.get(index))).setNegativeButton("Cancelar",null).show();
 }catch(Exception e){Toast.makeText(this,"No se pudo leer esta pantalla; usá carga manual",1).show();}});}
 void confirm(float remaining){android.content.SharedPreferences p=Plan.prefs(this);float total=p.getFloat(carrier+"total",0);if(total<=0||remaining>total){new AlertDialog.Builder(this).setMessage("Configurá primero los GB totales del plan. Si tenés extras, incluílos en el total. No se guardó el valor.").setPositiveButton("Aceptar",null).show();return;}
 new AlertDialog.Builder(this).setTitle("Confirmar saldo de "+carrier).setMessage("¿Son "+remaining+" GB disponibles para la línea que querés mostrar? Revisá que no sean GB consumidos, otra línea ni una oferta. El valor quedará fijo hasta otra importación.").setPositiveButton("Guardar",(d,w)->{p.edit().putFloat(carrier+"left",remaining).putLong(carrier+"stamp",System.currentTimeMillis()).putString(carrier+"source","importado y confirmado").apply();GigasWidget.refresh(this);Toast.makeText(this,"Saldo guardado en el widget",1).show();}).setNegativeButton("Cancelar",null).show();
 }
 void readPersonal(boolean manual){
 if(loading||!trusted()){if(manual)Toast.makeText(this,"Esperá a que cargue Personal",1).show();return;}
 final String url=web.getUrl();
 web.evaluateJavascript("document.body ? document.body.innerText.slice(0,150000) : ''",value->{if(!active||!trusted()||!url.equals(web.getUrl()))return;try{
 Object decoded=new JSONTokener(value).nextValue();if(!(decoded instanceof String))return;
 PersonalBalance b=PersonalBalance.parse((String)decoded);PersonalStore.save(this,b,url,true);
 address.setText(displayAddress(url)+" · saldo actualizado");if(manual)Toast.makeText(this,"Saldo actualizado en el panel y el widget",1).show();attempts=100;
 }catch(Exception e){if(manual){PersonalStore.error(this,e instanceof IllegalArgumentException?e.getMessage():"No se pudo leer el saldo");Toast.makeText(this,Plan.prefs(this).getString("personalError","No se pudo leer"),1).show();}}});
 }
 void startClaro(){claroSaved=false;attempts=0;auto.removeCallbacksAndMessages(null);autoClaro();}
 void autoClaro(){
 if(!active||claroSaved||!"claro".equals(carrier))return;
 if(attempts++>=45){address.setText("Claro · no se pudo identificar el saldo. Abrí el detalle y tocá Consultar.");return;}
 if(!loading&&trusted()&&!claroScript.isEmpty()){
 final String url=web.getUrl();
 web.evaluateJavascript(ClaroStore.script(this,claroScript,claroSelected),value->{if(!active||!trusted()||claroSaved)return;try{
 Object decoded=new JSONTokener(value).nextValue();if(!(decoded instanceof String))return;
 JSONObject result=new JSONObject((String)decoded);String status=result.optString("status");
 if("opening".equals(status)){String line=result.optString("line");if(ClaroStore.bind(this,line,true)){claroSelected=line;address.setText("Claro · abriendo tu línea…");}else address.setText("Claro · la línea no coincide con la vinculada");}
 else if(!url.equals(web.getUrl()))return;
 else if("choose".equals(status))address.setText("Claro · elegí la línea que querés consultar");
 else if("ambiguous".equals(status))address.setText("Claro · hay varios saldos. Abrí el detalle de datos.");
 else if("balance".equals(status)){
 if(!ClaroStore.bind(this,result.optString("line"),true))throw new IllegalArgumentException("La línea de Claro no coincide");ClaroStore.save(this,result,url);
 claroSaved=true;address.setText("Claro · saldo actualizado");Toast.makeText(this,"Saldo de Claro actualizado en el widget",1).show();
 }
 }catch(Exception e){address.setText(e instanceof IllegalArgumentException?e.getMessage():"Claro · saldo no verificado");}});
 }
 auto.postDelayed(this::autoClaro,2000);
 }
 void autoRead(){if(!active||!"personal".equals(carrier))return;if(attempts++<30){readPersonal(false);auto.postDelayed(this::autoRead,2000);}}
 protected void onResume(){super.onResume();active=true;if(web!=null&&"personal".equals(carrier)){attempts=0;// Keep the current verification form and focus when returning from mail.
auto.postDelayed(this::autoRead,1500);}else if(web!=null){attempts=0;auto.postDelayed(this::autoClaro,1500);}}
 protected void onSaveInstanceState(Bundle state){web.saveState(state);super.onSaveInstanceState(state);}
 protected void onPause(){active=false;auto.removeCallbacksAndMessages(null);CookieManager.getInstance().flush();super.onPause();}
 public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 protected void onDestroy(){auto.removeCallbacksAndMessages(null);web.stopLoading();web.destroy();super.onDestroy();}
}
