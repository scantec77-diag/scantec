package ar.ari.gigas;
import android.content.*;import android.content.pm.*;import org.json.*;import java.net.*;import java.io.*;import java.security.*;import java.util.*;import java.util.concurrent.atomic.AtomicBoolean;
final class UpdateManager {
 static long version(Context c){try{return c.getPackageManager().getPackageInfo(c.getPackageName(),0).getLongVersionCode();}catch(PackageManager.NameNotFoundException e){throw new IllegalStateException(e);}}
 static String versionName(Context c){try{return c.getPackageManager().getPackageInfo(c.getPackageName(),0).versionName;}catch(PackageManager.NameNotFoundException e){throw new IllegalStateException(e);}}
 static final String ROOT="https://raw.githubusercontent.com/scantec77-diag/scantec/misgigas-updates/misgigas/";
 static final AtomicBoolean checking=new AtomicBoolean();
 static boolean hasUpdate(Context c){return Plan.prefs(c).getInt("updateVersion",0)>version(c);}
 static void checkAsync(Context source){Context c=source.getApplicationContext();if(System.currentTimeMillis()-Plan.prefs(c).getLong("updateChecked",0)<10*60*1000L||!checking.compareAndSet(false,true))return;new Thread(()->{try{check(c);}catch(Exception ignored){}finally{checking.set(false);}},"MisGigas-update").start();}
 static HttpURLConnection connect(String url)throws Exception {if(!url.startsWith(ROOT)||url.contains("..")||url.contains("?")||url.contains("#"))throw new IOException("Dirección de actualización inválida");HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setConnectTimeout(12000);h.setReadTimeout(20000);h.setInstanceFollowRedirects(false);h.setUseCaches(false);if(h.getResponseCode()!=200){h.disconnect();throw new IOException("No se pudo consultar el servidor");}return h;}
 static byte[] readLimited(InputStream in,int max)throws IOException {ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>max)throw new IOException("Archivo demasiado grande");out.write(b,0,n);}return out.toByteArray();}
 static String check(Context c)throws Exception {
  HttpURLConnection h=connect(ROOT+"updates.json");byte[] data;try(InputStream in=h.getInputStream()){data=readLimited(in,65536);}finally{h.disconnect();}
  JSONObject o=new JSONObject(new String(data,java.nio.charset.StandardCharsets.UTF_8));if(!"ar.ari.gigas".equals(o.getString("packageName")))throw new IOException("Actualización para otra aplicación");
  int v=o.getInt("versionCode");String name=o.getString("versionName"),url=o.getString("apkUrl"),hash=o.getString("sha256");if(v<1||name.length()>30||!url.startsWith(ROOT)||!url.endsWith(".apk")||!hash.matches("[a-fA-F0-9]{64}"))throw new IOException("Datos de actualización inválidos");
  android.content.SharedPreferences prefs=Plan.prefs(c);android.content.SharedPreferences.Editor e=prefs.edit();
  JSONObject style=o.optJSONObject("style");int rev=o.optInt("styleRevision",0);
  if(style!=null&&rev>prefs.getInt("styleRevision",0)){
   float low=(float)style.getDouble("lowGb"),high=(float)style.getDouble("highGb");if(!Float.isFinite(low)||!Float.isFinite(high)||low<=0||high<=low||high>10000)throw new IOException("Umbrales inválidos");
   int red=parseColor(style.getString("red")),yellow=parseColor(style.getString("yellow")),green=parseColor(style.getString("green")),text=parseColor(style.getString("text"));
   if(style.has("orange")){int orange=parseColor(style.getString("orange"));float a=(float)style.getDouble("orangeGb"),b=(float)style.getDouble("yellowGb"),d=(float)style.getDouble("greenGb");if(!Float.isFinite(a)||!Float.isFinite(b)||!Float.isFinite(d)||a<=0||b<=a||d<=b||d>10000)throw new IOException("Escala inválida");e.putInt("styleOrange",orange).putFloat("styleOrangeGb",a).putFloat("styleYellowGb",b).putFloat("styleGreenGb",d);}
   e.putInt("styleRed",red).putInt("styleYellow",yellow).putInt("styleGreen",green).putInt("styleText",text).putFloat("styleLowGb",low).putFloat("styleHighGb",high).putInt("styleRevision",rev);
  }
  e.putInt("updateVersion",v).putString("updateName",name).putString("updateUrl",url).putString("updateHash",hash.toLowerCase(Locale.ROOT)).putLong("updateChecked",System.currentTimeMillis()).apply();GigasWidget.refresh(c);
  return v>version(c)?"Nueva versión "+name:"Ya tenés MisGigas "+versionName(c)+". Apariencia sincronizada.";
 }
 static int parseColor(String s)throws IOException {if(!s.matches("#[a-fA-F0-9]{6}"))throw new IOException("Color inválido");return (int)(0xff000000L|Long.parseLong(s.substring(1),16));}
 static synchronized File download(Context c)throws Exception {
  android.content.SharedPreferences p=Plan.prefs(c);int version=p.getInt("updateVersion",0);String url=p.getString("updateUrl",""),hash=p.getString("updateHash","");if(version<=version(c))throw new IOException("No hay una versión nueva");
  File temp=File.createTempFile("misgigas-",".part",c.getCacheDir());boolean installed=false;
  try{HttpURLConnection h=connect(url);MessageDigest digest=MessageDigest.getInstance("SHA-256");try(InputStream in=h.getInputStream();OutputStream out=new FileOutputStream(temp)){byte[] b=new byte[16384];int n;long size=0;while((n=in.read(b))!=-1){size+=n;if(size>25*1024*1024)throw new IOException("La descarga supera el tamaño permitido");out.write(b,0,n);digest.update(b,0,n);}}finally{h.disconnect();}
   StringBuilder actual=new StringBuilder();for(byte b:digest.digest())actual.append(String.format(Locale.ROOT,"%02x",b&255));if(!actual.toString().equals(hash))throw new IOException("Descarga incompleta o modificada. Volvé a intentar.");
   PackageManager pm=c.getPackageManager();PackageInfo candidate=pm.getPackageArchiveInfo(temp.getAbsolutePath(),PackageManager.GET_SIGNING_CERTIFICATES),current=pm.getPackageInfo(c.getPackageName(),PackageManager.GET_SIGNING_CERTIFICATES);
   if(candidate==null||!c.getPackageName().equals(candidate.packageName)||candidate.getLongVersionCode()!=version||candidate.signingInfo==null||current.signingInfo==null)throw new IOException("La APK no corresponde a esta versión");
   Set<String> own=signatures(current),next=signatures(candidate);if(own.isEmpty()||!own.equals(next))throw new IOException("La firma de la actualización no coincide");
   File dest=new File(c.getCacheDir(),"update.apk");if(dest.exists()&&!dest.delete())throw new IOException("No se pudo preparar la actualización");if(!temp.renameTo(dest))throw new IOException("No se pudo guardar la actualización");installed=true;return dest;
  }finally{if(!installed)temp.delete();}
 }
 static Set<String> signatures(PackageInfo p){Set<String> set=new HashSet<>();for(android.content.pm.Signature s:p.signingInfo.getApkContentsSigners())set.add(s.toCharsString());return set;}
}
