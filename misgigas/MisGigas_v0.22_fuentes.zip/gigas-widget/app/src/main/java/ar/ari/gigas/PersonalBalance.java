package ar.ari.gigas;
import java.util.*;
import java.util.regex.*;
import java.time.*;
/** Strict parser for the Personal general-use card. Rejects ambiguous pages. */
final class PersonalBalance {
 final float total,left; final String line,renewal;
 PersonalBalance(float t,float l,String id,String date){total=t;left=l;line=id;renewal=date;}
 static final Pattern AMOUNTS=Pattern.compile("([0-9]+(?:[.,][0-9]+)?)\\s*GB\\s+disponibles\\s+([0-9]+(?:[.,][0-9]+)?)\\s*GB\\b",Pattern.CASE_INSENSITIVE);
 static PersonalBalance parse(String raw){
  if(raw==null)throw new IllegalArgumentException("No se pudo leer Personal");
  String text=raw.replace('\u00a0',' ').replaceAll("\\s+"," ").trim();
  Matcher lineMatch=Pattern.compile("Est[aá]s gestionando el servicio\\s*:?\\s*([+0-9][0-9 ()-]{6,25})",Pattern.CASE_INSENSITIVE).matcher(text);
  Set<String> lines=new HashSet<>();while(lineMatch.find())lines.add(lineMatch.group(1).replaceAll("[^0-9]",""));
  if(lines.size()!=1)throw new IllegalArgumentException("Abrí Personal para identificar tu línea");
  String lower=text.toLowerCase(Locale.ROOT);int from=0;PersonalBalance result=null;
  while((from=lower.indexOf("datos para todo uso",from))>=0){
   int start=from;from+=19;
   int renewalAt=lower.indexOf("los gigas del plan se renuevan",from);
   if(renewalAt<0||renewalAt-start>1200)continue;
   String card=text.substring(from,renewalAt);Matcher m=AMOUNTS.matcher(card);
   if(!m.find())continue;
   float left=Float.parseFloat(m.group(1).replace(',','.')),total=Float.parseFloat(m.group(2).replace(',','.'));
   if(m.find()||!Float.isFinite(left)||!Float.isFinite(total)||total<=0||left<0||left>total)throw new IllegalArgumentException("Saldo ambiguo: no se modificó el último dato");
   Matcher date=Pattern.compile("Los gigas del plan se renuevan el (\\d{1,2})/(\\d{1,2})/(\\d{2,4})",Pattern.CASE_INSENSITIVE).matcher(text.substring(renewalAt,Math.min(text.length(),renewalAt+100)));
   String renewal="";if(date.find())try{int y=Integer.parseInt(date.group(3));if(y<100)y+=2000;renewal=LocalDate.of(y,Integer.parseInt(date.group(2)),Integer.parseInt(date.group(1))).toString();}catch(Exception ignored){}
   PersonalBalance next=new PersonalBalance(total,left,lines.iterator().next(),renewal);
   if(result!=null&&(result.left!=next.left||result.total!=next.total))throw new IllegalArgumentException("Hay más de un saldo: abrí el detalle de tu línea");
   result=next;
  }
  if(result==null)throw new IllegalArgumentException("No se encontró el saldo de Datos para todo uso; abrí Personal y revisá la sesión");
  return result;
 }
}
