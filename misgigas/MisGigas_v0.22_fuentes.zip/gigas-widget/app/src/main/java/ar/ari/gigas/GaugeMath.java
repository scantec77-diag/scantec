package ar.ari.gigas;
final class GaugeMath {
 static float ratio(float total,float left){return Float.isFinite(total)&&Float.isFinite(left)&&total>0?Math.max(0,Math.min(1,left/total)):0;}
 static int color(float gb,int red,int yellow,int green,float low,float high){float x=Float.isFinite(gb)?Math.max(0,gb):0;return x<=low?mix(red,yellow,x/low):mix(yellow,green,Math.min(1,(x-low)/(high-low)));}
 static int color4(float gb,int red,int orange,int yellow,int green,float orangeGb,float yellowGb,float greenGb){float x=Float.isFinite(gb)?Math.max(0,gb):0;if(x<=orangeGb)return mix(red,orange,x/orangeGb);if(x<=yellowGb)return mix(orange,yellow,(x-orangeGb)/(yellowGb-orangeGb));return mix(yellow,green,Math.min(1,(x-yellowGb)/(greenGb-yellowGb)));}
 static int mix(int a,int b,float t){t=Math.max(0,Math.min(1,t));int r=Math.round(((a>>16)&255)*(1-t)+((b>>16)&255)*t),g=Math.round(((a>>8)&255)*(1-t)+((b>>8)&255)*t),bl=Math.round((a&255)*(1-t)+(b&255)*t);return 0xff000000|(r<<16)|(g<<8)|bl;}
}
