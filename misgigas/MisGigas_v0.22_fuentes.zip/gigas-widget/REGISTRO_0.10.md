# MisGigas 0.10 — colores y widget ajustable

12/11/2026, Argentina. Ari confirmó que con la 0.9 pudo entrar en Personal y guardar la cuenta. Mantener la corrección de validación.

Pedido: cuatro colores rojo, naranja, amarillo y verde unidos con transición suave; fondo gris ratón; todavía no puede redimensionar el widget en Samsung.

Implementado: arco SweepGradient con colores interpolados según GB absolutos. Escala inicial: rojo 0 GB, naranja 5 GB, amarillo 10 GB, verde desde 20 GB. La longitud sigue siendo la proporción del plan; la escala de color no usa porcentajes. Feed remoto styleRevision 2 con orange y umbrales orangeGb/yellowGb/greenGb; 0.10 los admite. Fondo sólido gris #555555 y texto blanco en negrita.

Redimensión: proveedor nuevo GigasFlexibleWidget, nombre visible MisGigas · ajustable, para obtener metadatos nuevos del launcher. Ambos ejes, mínimo solicitado 80 × 100 dp, tamaño inicial 3 × 2 celdas. Composición adaptable: oculta encabezado bajo 160 dp y fecha bajo 200 dp, conserva saldo y botón de actualización. El botón Agregar widget de la app agrega este nuevo proveedor. El proveedor anterior permanece funcionando para no borrar automáticamente widgets del usuario. Las actualizaciones de saldo y configuración refrescan ambos proveedores.

Validado: compilación y firma debug; pruebas de los cuatro extremos de color y continuidad de los tres umbrales; inspección de metadatos y color gris. Se publica APK 0.10 con versionCode 10 y su SHA256 en el canal remoto.

Pendiente Samsung: tocar Buscar actualización e instalar 0.10; quitar solo el widget anterior; abrir MisGigas y tocar Agregar widget para añadir MisGigas · ajustable. Mantener presionado y revisar si aparece marco y tiradores. Si no aparecen, comprobar si el inicio tiene bloqueado el diseño y registrar launcher/ajustes, sin asumir que ese sea el problema. La causa del bloqueo no quedó reproducida ni confirmada; no afirmar que está resuelto hasta la prueba del usuario.

Respaldo: mantiene clave debug previa dentro de los fuentes para poder actualizar encima. No publicar esa clave. Ver REGISTRO_0.9.md y REGISTRO_0.8.md para continuidad y arquitectura. La API remota admite colores y umbrales preparados; cambios nativos requieren APK y confirmación de Android.
