Mis Gigas 0.20 — widget Mi Tablero

Se agrega un AppWidgetProvider real con Personal, Claro, Wi-Fi diario, tethering diario y batería. Botón Agregar widget Mi Tablero en la app solicita fijarlo mediante Android. Alternativa: Widgets del inicio, Mis Gigas · Mi Tablero. Tamaño predeterminado 4×5, ajustable; mínimo vertical para evitar recortar el detalle. Flecha consulta saldos y toma una nueva muestra local; tocar el resto abre el tablero. Widgets previos también abren el tablero. Conserva paquete, preferencias y firma de 0.19.

Actualización del widget: solicitud periódica de Android cada 30 min, sujeta a ahorro de energía; manual con flecha, al regresar de la app y al guardarse saldos. No es un monitor continuo segundo a segundo. Cada sección incluye fecha de lectura para identificar datos anteriores. No se mantiene un servicio permanente. Batería se consulta mediante el lector compartido con la pantalla. Consumos se leen en segundo plano con acceso al uso; falta de registros de tethering se muestra como tal, no como cero.

Verificación: compilación de recursos y Java, empaquetado DEX, firma v3. Pendiente prueba visual y comportamiento del launcher Samsung real; no hay emulador Android en este entorno. Fuentes sin clave privada.
