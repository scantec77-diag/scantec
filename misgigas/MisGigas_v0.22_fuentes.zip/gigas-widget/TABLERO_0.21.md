# Mis Gigas 0.21

Indicadores semicirculares con gradiente rojo, naranja, amarillo y verde en app y widget: Personal, Claro, Wi-Fi, Compartidos, batería y salud.
Saldos y batería usan proporción restante. Consumo diario usa escala automática visible (no es cupo ni restante). Sin datos: guion y arco gris.
Carga: conexión, corriente neta, voltaje de batería y potencia neta calculada. Límite de carga informado por Android si entrega max_charging_current y max_charging_voltage; no representa potencia medida en el enchufe ni potencia nominal del cargador.
App refresca batería cada 3 segundos y al recibir cambios; widget al abrir/cerrar app, consultar saldos, actualización del launcher y flecha. Eventos de conexión en segundo plano dependen de Android; sin servicio continuo.
Compilación y firma v3 verificadas, misma identidad que 0.20. Prueba con BatterySnapshot y stubs: unidades µA/mV, límites µA/µV, signo neto, conectado sin carga y valores ausentes. Pendiente validación visual y lecturas en Samsung SM-S938B Android 17.
