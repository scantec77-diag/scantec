package ar.ari.gigas;
public class PersonalLoginChecks {
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){long now=10000000L;check(PersonalLoginPolicy.mayAttempt(false,0,now));long retry=PersonalLoginPolicy.retryAt(now);check(retry==now+900000L);check(!PersonalLoginPolicy.mayAttempt(false,retry,now));check(PersonalLoginPolicy.mayAttempt(false,retry,retry));check(!PersonalLoginPolicy.mayAttempt(true,0,now));check(PersonalLoginPolicy.mayAttempt(false,now+2*PersonalLoginPolicy.RETRY_DELAY,now));System.out.println("Login policy: first attempt, persistent cooldown, retry, verification pause and clock rollback passed.");}
}
