"""Exercise the actual scheduling class using an isolated Android scheduler double."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[1]
files={
'android/content/ComponentName.java':'package android.content; public class ComponentName {public ComponentName(Context c,Class<?> t){}}',
'android/content/Context.java':'package android.content; public class Context {public android.app.job.JobScheduler scheduler=new android.app.job.JobScheduler(); public <T>T getSystemService(Class<T> c){return c.cast(scheduler);}}',
'android/os/Build.java':'package android.os; public class Build {public static class VERSION {public static int SDK_INT=35;}}',
'android/app/job/JobInfo.java':'''package android.app.job; public class JobInfo {public static final int NETWORK_TYPE_ANY=1; public int id,network;public boolean persisted,expedited;public long interval,flex,deadline=-1; public static class Builder {JobInfo j=new JobInfo(); public Builder(int id,android.content.ComponentName n){j.id=id;}public Builder setRequiredNetworkType(int n){j.network=n;return this;}public Builder setPersisted(boolean p){j.persisted=p;return this;}public Builder setPeriodic(long i,long f){j.interval=i;j.flex=f;return this;}public Builder setExpedited(boolean e){j.expedited=e;return this;}public Builder setOverrideDeadline(long d){j.deadline=d;return this;}public JobInfo build(){return j;}}}''',
'android/app/job/JobScheduler.java':'''package android.app.job; import java.util.*;public class JobScheduler {public static final int RESULT_SUCCESS=1;public List<JobInfo> calls=new ArrayList<>();public boolean rejectExpedited=false,rejectAll=false;public JobInfo getPendingJob(int id){return calls.stream().filter(j->j.id==id).findFirst().orElse(null);}public int schedule(JobInfo j){calls.add(j);return rejectAll||(rejectExpedited&&j.expedited)?0:1;}}''',
'ar/ari/gigas/ClaroJobService.java':'package ar.ari.gigas;public class ClaroJobService {}',
'ar/ari/gigas/ClaroStore.java':'package ar.ari.gigas;class ClaroStore {static boolean linked=true,busy=false;static String error="";static boolean linked(android.content.Context c){return linked;}static boolean busy(android.content.Context c){return busy;}static void error(android.content.Context c,String e){error=e;}}',
'ar/ari/gigas/Plan.java':'package ar.ari.gigas;class Plan {static Plan prefs(android.content.Context c){return new Plan();}Plan edit(){return this;}Plan putLong(String k,long v){return this;}Plan putString(String k,String v){return this;}void apply(){}}',
'ar/ari/gigas/GigasWidget.java':'package ar.ari.gigas;class GigasWidget {static void refresh(android.content.Context c){}}',
'ar/ari/gigas/Check.java':'''package ar.ari.gigas;import android.content.*;import android.app.job.*;public class Check {static void check(boolean b){if(!b)throw new AssertionError();}public static void main(String[] args){Context c=new Context();ClaroStore.linked=false;check(!ClaroJobs.ensure(c)&&c.scheduler.calls.isEmpty());ClaroStore.linked=true;check(ClaroJobs.ensure(c));JobInfo j=c.scheduler.calls.get(0);check(j.id==701&&j.persisted&&j.interval==900000&&j.network==1);ClaroJobs.ensure(c);check(c.scheduler.calls.size()==1);ClaroStore.busy=true;ClaroJobs.now(c);check(c.scheduler.calls.size()==1);ClaroStore.busy=false;c.scheduler.rejectExpedited=true;ClaroJobs.now(c);check(c.scheduler.calls.size()==3);check(c.scheduler.calls.get(1).expedited);check(!c.scheduler.calls.get(2).expedited&&c.scheduler.calls.get(2).deadline==0);c.scheduler.rejectAll=true;ClaroJobs.now(c);check(!ClaroStore.error.isEmpty());android.os.Build.VERSION.SDK_INT=29;c.scheduler.rejectAll=false;ClaroJobs.now(c);check(c.scheduler.calls.get(c.scheduler.calls.size()-1).deadline==0);System.out.println("Claro scheduling: unlinked, 15-minute persisted job, deduplication, busy guard, expedited fallback, failure reporting, Android 10 passed.");}}'''
}
with tempfile.TemporaryDirectory() as temp:
 base=Path(temp)
 for name,text in files.items():
  p=base/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 (base/'ar/ari/gigas/ClaroJobs.java').write_text((root/'app/src/main/java/ar/ari/gigas/ClaroJobs.java').read_text())
 subprocess.run(['java','com.sun.tools.javac.Main','-d',str(base),*map(str,base.rglob('*.java'))],check=True)
 subprocess.run(['java','-cp',str(base),'ar.ari.gigas.Check'],check=True)
# The refresh control must be a receiver action, never an Activity PendingIntent.
widget=(root/'app/src/main/java/ar/ari/gigas/ClaroWidget.java').read_text()
assert 'PendingIntent.getBroadcast(c,21,new Intent(c,ClaroWidget.class).setAction(UPDATE)' in widget
assert 'ClaroJobs.now(c)' in widget
sync=(root/'app/src/main/java/ar/ari/gigas/ClaroSync.java').read_text()
assert 'startActivity' not in sync
print('Widget refresh dispatches to background job; no Activity launched by ClaroSync.')
