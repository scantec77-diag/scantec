package ar.ari.gigas;
public class GaugeChecks {
 static void eq(int a,int b){if(a!=b)throw new AssertionError(Integer.toHexString(a)+" != "+Integer.toHexString(b));}
 public static void main(String[] args){int r=0xfff45b69,y=0xffffca45,g=0xff4ce5a2;eq(GaugeMath.color(0,r,y,g,5,15),r);eq(GaugeMath.color(5,r,y,g,5,15),y);eq(GaugeMath.color(15,r,y,g,5,15),g);eq(GaugeMath.color(100,r,y,g,5,15),g);eq(GaugeMath.color(Float.NaN,r,y,g,5,15),r);if(GaugeMath.ratio(50,25)!=.5f||GaugeMath.ratio(10,20)!=1||GaugeMath.ratio(0,2)!=0)throw new AssertionError();for(float boundary:new float[]{5,15}){int before=GaugeMath.color(boundary-.001f,r,y,g,5,15),after=GaugeMath.color(boundary+.001f,r,y,g,5,15);for(int shift:new int[]{0,8,16})if(Math.abs(((before>>shift)&255)-((after>>shift)&255))>1)throw new AssertionError("Color discontinuity");}System.out.println("Gauge: absolute GB thresholds, smooth boundaries, ratio and invalid inputs PASS");}
}
