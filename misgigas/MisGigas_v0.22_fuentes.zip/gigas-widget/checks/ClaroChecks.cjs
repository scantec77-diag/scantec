const fs=require('fs'),vm=require('vm'),assert=require('assert');
const code=fs.readFileSync(__dirname+'/../app/src/main/assets/claro-read.js','utf8');
function el(innerText,click=()=>{}){return {innerText,children:[],getClientRects:()=>[{}],closest:()=>null,click};}
function run(text,{cards=[],lines=[],expected='113426100',selected='113426100',password=false,window={}}={}){
 Object.assign(window,{__misGigasClaroLine:expected,__misGigasClaroSelected:selected});
 return JSON.parse(vm.runInNewContext(code,{document:{body:{innerText:text},querySelector:()=>password?{}:null,querySelectorAll:q=>q.startsWith('button')?lines:cards.map(x=>el(x))},window,getComputedStyle:()=>({visibility:'visible',display:'block'})}));
}
const check=(card,options)=>run(card,{cards:[card],...options});
let n=0;const test=(name,f)=>{f();n++;};
test('open exact single line once',()=>{let clicks=0,w={};let opts={lines:[el('113426100',()=>clicks++)],expected:'',selected:'',window:w};assert.equal(run('¿Qué servicio querés consultar?',opts).status,'opening');assert.equal(run('¿Qué servicio querés consultar?',opts).status,'wait');assert.equal(clicks,1);});
test('select linked line among several',()=>{assert.equal(run('¿Qué servicio querés consultar?',{lines:[el('113426100'),el('1144556666')]}).line,'113426100');});
test('refuse choosing several unknown lines',()=>{assert.equal(run('¿Qué servicio querés consultar?',{expected:'',lines:[el('113426100'),el('1144556666')]}).status,'choose');});
test('refuse different linked line',()=>{assert.equal(run('¿Qué servicio querés consultar?',{lines:[el('1144556666')]}).status,'choose');});
test('remaining and total explicit',()=>assert.deepEqual(check('Internet 12,5 GB disponibles de 20 GB'),{status:'balance',line:'113426100',left:12.5,total:20}));
test('zero balance',()=>assert.equal(check('Datos 0 GB restantes de 20 GB').left,0));
test('label before amount',()=>assert.equal(check('Datos disponibles: 12 GB de 20 GB').left,12));
test('no arbitrary unique amount',()=>assert.equal(check('Datos 12 GB disponibles').status,'unverified'));
test('no consumed balance',()=>assert.equal(check('Internet 12 GB consumidos de 20 GB').status,'unverified'));
test('no promotions',()=>assert.equal(check('Oferta Internet 12 GB disponibles de 20 GB').status,'unverified'));
test('no social data',()=>assert.equal(check('Internet WhatsApp 12 GB disponibles de 20 GB').status,'unverified'));
test('two different balances',()=>assert.equal(run('Internet',{cards:['Internet 12 GB disponibles de 20 GB','Internet 3 GB disponibles de 10 GB']}).status,'ambiguous'));
test('line unknown',()=>assert.equal(check('Internet 12 GB disponibles de 20 GB',{selected:''}).status,'unverified'));
test('different page line',()=>assert.equal(check('Línea: 1144556666 Internet 12 GB disponibles de 20 GB').status,'unverified'));
test('Spanish thousands',()=>assert.equal(check('Internet 1.234,50 GB disponibles de 2.000 GB').left,1234.5));
test('MB conversion unknown',()=>assert.equal(check('Internet 1.234 MB disponibles de 2.000 MB').status,'unverified'));
test('login',()=>assert.equal(run('Ingresá tu contraseña',{password:true}).status,'login'));
test('remaining exceeds total',()=>assert.equal(check('Internet 21 GB disponibles de 20 GB').status,'unverified'));
console.log(`Claro: ${n} regression checks passed.`);
