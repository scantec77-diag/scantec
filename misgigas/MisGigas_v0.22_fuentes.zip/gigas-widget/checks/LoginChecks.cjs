const fs=require('fs'),vm=require('vm'),assert=require('assert');
const source=fs.readFileSync(__dirname+'/../app/src/main/assets/personal-login.js','utf8');
function run({host='mipersonal.personal.com.ar',kind='email',body='',action='',duplicate=false,allowEmail=true,allowPassword=true,button='Siguiente',frame=false,submit=true,placeholder='',name='',captcha=false,otp=false,buttonDisabled=false}={}){
 let clicks=0;class Input{set value(v){this._value=v}get value(){return this._value}getClientRects(){return [1]}dispatchEvent(){}}
 const input=new Input();input.type=kind;input.name=name||(kind==='email'?'email':'password');input.autocomplete=otp?'one-time-code':'';input.placeholder=placeholder;
 const b={disabled:buttonDisabled,innerText:button,getClientRects:()=>[1],click(){clicks++}};
 input.form={target:'',getAttribute:()=>action,querySelectorAll:()=>[b]};
 const context={location:{protocol:'https:',hostname:host,href:'https://'+host+'/login',origin:'https://'+host},document:{body:{innerText:body},querySelectorAll:q=>q==='input'?(duplicate?[input,input]:[input]):(captcha?[b]:[])},HTMLInputElement:Input,URL,Event:class{}};context.window={};context.window.self=context.window;context.window.top=frame?{}:context.window;
 const f=vm.runInNewContext(source,context);return {result:f('example@example.com','fixture-password',allowEmail,allowPassword,submit),clicks,value:input.value};
}
assert.equal(run().result,'email');assert.equal(run().clicks,1);
assert.equal(run({kind:'password',button:'Ingresar'}).result,'password');
for(const x of [{host:'example.com'},{host:'mipersonal.personal.com.ar.example.com'},{action:'https://example.com/'},{frame:true},{button:'Borrar cuenta'}])assert.equal(run(x).clicks,0);
assert.equal(run({body:'Código de verificación',otp:true}).result,'blocked');
assert.equal(run({kind:'password',body:'También podés ingresar con código de verificación'}).result,'password');
assert.equal(run({submit:false}).result,'email');assert.equal(run({submit:false}).clicks,0);assert.equal(run({submit:false}).value,undefined);
assert.equal(run({kind:'text',name:'mail'}).result,'email');
assert.equal(run({kind:'text',name:'field1',placeholder:'Ingresá tu correo electrónico'}).result,'email');
assert.equal(run({captcha:true}).result,'blocked');
assert.equal(run({buttonDisabled:true,submit:false}).result,'email');
assert.equal(run({buttonDisabled:true}).result,'waiting');assert.equal(run({buttonDisabled:true}).clicks,0);
assert.equal(run({body:'Contraseña incorrecta'}).clicks,0);
assert.equal(run({allowEmail:false}).clicks,0);
assert.equal(run({kind:'password',allowPassword:false}).clicks,0);
assert.equal(run({duplicate:true}).clicks,0);
console.log('LoginChecks: OK (preview sin escribir, mail/texto, alternativas de código, CAPTCHA/OTP, origen, formulario y límites)');
