package ar.ari.gigas;
import java.time.*;import java.util.regex.*;
public class GigasChecks {
 public static void main(String[] args){
  if(!Plan.boundary(YearMonth.of(2027,2),31).equals(LocalDate.of(2027,2,28)))throw new AssertionError("February");
  if(!Plan.boundary(YearMonth.of(2028,2),31).equals(LocalDate.of(2028,2,29)))throw new AssertionError("Leap");
  for(int d=1;d<=31;d++){if(Plan.start(d).isAfter(LocalDate.now())||!Plan.next(d).isAfter(LocalDate.now()))throw new AssertionError("Cycle "+d);}
  Pattern p=Pattern.compile("(?i)([0-9]+(?:[.,][0-9]+)?)\\s*(GB|gigas?)(?![a-z])");
  for(String s:new String[]{"Disponibles 9,25 GB","Te quedan 10 gigas","6.5GB"})if(!p.matcher(s).find())throw new AssertionError(s);
  if(p.matcher("50 MB").find())throw new AssertionError("Units");
  System.out.println("OK: calendario, días 1–31 y lectura de unidades GB.");
 }
}
