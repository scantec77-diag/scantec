package ar.ari.gigas;
public class PersonalChecks {
 static int checks;
 static String page(String values){return "Personal Móvil Estás gestionando el servicio: 1100000000 - Línea de prueba Mis disponibles Datos para todo uso Beneficio Duplicá Gigas activo "+values+" Los gigas del plan se renuevan el 14/12/26. Ganaste 2 GB por tus recargas. Tenés 2 GB para el exterior.";}
 static void ok(boolean b,String name){checks++;if(!b)throw new AssertionError(name);}
 static void rejects(String text,String name){checks++;try{PersonalBalance.parse(text);}catch(IllegalArgumentException expected){return;}throw new AssertionError(name);}
 public static void main(String[] args){
  PersonalBalance b=PersonalBalance.parse(page("42,6 GB disponibles 60,5 GB"));
  ok(b.left==42.6f&&b.total==60.5f,"remaining and total, not promo");
  ok(b.line.equals("1100000000"),"line identifier");ok(b.renewal.equals("2026-12-14"),"renewal");
  ok(Math.abs((b.total-b.left)-17.9)<0.001,"used calculation");ok(Math.abs(b.left/b.total*100-70.41322)<0.001,"percentage");
  b=PersonalBalance.parse(page("42.6\u00a0GB\n disponibles\n60.5 GB"));ok(b.left==42.6f,"spaces and decimals");
  ok(PersonalBalance.parse(page("0 GB disponibles 60 GB")).left==0,"zero balance is valid");
  ok(PersonalBalance.parse(page("60 GB disponibles 60 GB")).left==60,"full plan");
  rejects(page("61 GB disponibles 60 GB"),"left exceeds total");rejects(page("0 GB disponibles 0 GB"),"zero total");
  rejects(page("42 MB disponibles 60 GB"),"wrong unit");rejects(page("42 GB consumidos 60 GB"),"consumed is not remaining");
  rejects("42 GB disponibles 60 GB", "outside general-use card");
  rejects(page("42 GB disponibles 60 GB").replace("Estás gestionando el servicio: 1100000000 - Línea de prueba", ""),"missing line");
  rejects(page("42 GB disponibles 60 GB")+" Estás gestionando el servicio: 1199999999 - Otra", "multiple lines");
  rejects(page("42 GB disponibles 60 GB")+page("41 GB disponibles 60 GB"),"conflicting cards");
  ok(PersonalBalance.parse(page("42 GB disponibles 60 GB")+page("42 GB disponibles 60 GB")).left==42,"identical duplicated card");
  rejects(page("42 GB disponibles 60 GB 41 GB disponibles 60 GB"),"ambiguous values inside card");
  rejects("Iniciar sesión con tu contraseña", "logged out");rejects(null,"null input");
  System.out.println("OK: "+checks+" comprobaciones de lectura, cálculo y rechazo de páginas ambiguas.");
 }
}
