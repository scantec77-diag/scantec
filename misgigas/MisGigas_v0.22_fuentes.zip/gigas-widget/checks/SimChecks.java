package ar.ari.gigas;
public class SimChecks {public static void main(String[] args){
 if(Math.abs(SimStats.left(42.7,1000000000L,1250000000L)-42.45)>1e-9)throw new AssertionError("delta");
 if(SimStats.left(1,0,2000000000L)!=0)throw new AssertionError("zero floor");
 if(SimStats.left(42.7,100,100)!=42.7)throw new AssertionError("unchanged");
 try{SimStats.left(42.7,100,99);throw new AssertionError("rollback accepted");}catch(IllegalArgumentException good){}
 System.out.println("OK: descuento por diferencia, cero, contador sin cambios y retroceso bloqueado.");
}}
