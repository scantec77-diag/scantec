# MisGigas 0.9 — validación Personal

12/11/2026, Argentina. Ari informa que al tocar casilleros del código de validación de Personal vuelve al paso del correo.

Cambios: retirada la recarga automática del portal en onResume (ocurría al volver desde el correo); configuración para mantener la misma actividad al abrir teclado o rotar, con adjustResize; guardado/restauración de historial WebView ante recreaciones; los subframes de ventanas emergentes ya no se promueven a navegación principal. No se capturan correo, contraseña, código ni cookies fuera de WebView.

Validado: compilación APK debug 0.9, firma válida e idéntica a la 0.8; comprobaciones de código de ausencia de recarga al volver, historial y configuración del teclado. Conserva el widget y el actualizador de 0.8. Canal remoto publicado con versionCode 9 y SHA256 de la nueva APK.

Pendiente: reproducir el flujo real de Personal en el Samsung; no se ha probado una cuenta ni se asegura que esta sea la causa única del retroceso. Probar código nuevo y vigente después de instalar; salir al correo y volver, tocar casillero e ingresar código. Si persiste, precisar si vuelve al paso del correo sin salir de MisGigas y si sucede al tocar cualquier casillero. Nunca pedir ni guardar la contraseña o el código.

Instalación: desde el widget de 0.8, Buscar actualización (consulta forzada) → detecta 0.9 → descarga y verifica firma → instalador Android. También se entrega la APK directa como alternativa. El canal puede tardar unos minutos en reflejar la publicación por caché.

Ver REGISTRO_0.8.md para arquitectura del actualizador y continuidad previa. En futuras versiones actualizar VERSION y las etiquetas de versión en UpdateManager, build.gradle, build_manual.py y MainActivity. Mantener la misma clave de desarrollo. No publicar la clave de firma.
