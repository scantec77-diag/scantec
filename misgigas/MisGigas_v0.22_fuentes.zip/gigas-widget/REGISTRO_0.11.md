# MisGigas 0.11 — acceso automático experimental

13/11/2026, Argentina.

Ari autorizó guardar localmente el mail y la contraseña para recuperar el acceso a Personal y consultar saldo desde Actualizar y desde el trabajo periódico existente de 15 minutos. Android puede demorar las consultas. No se creó un recordatorio ni una automatización externa.

## Uso
Instalar esta APK encima de la anterior, sin desinstalar ni borrar datos. En MisGigas abrir «Guardar acceso automático de Personal», cargar mail y contraseña y Guardar. Si aún no está vinculada la línea, entrar primero a Personal e importar un saldo válido. Luego tocar Actualizar Personal.

Las credenciales se cargan expresamente en el diálogo nativo; no se capturan al escribirlas en el portal. Si cambia la contraseña hay que actualizarla en ese diálogo. «Borrar acceso» desactiva la reconexión y elimina el registro cifrado; no cierra por sí solo la sesión web existente.

## Implementación
AES-GCM con clave AndroidKeyStore y preferencias privadas, backup deshabilitado. Diálogo con protección contra capturas y guardado automático de vistas deshabilitado. No se muestran credenciales guardadas. No se añadieron logs de credenciales, puentes JavaScript ni permisos.

La consulta intenta reutilizar la sesión; si no puede leer el saldo, intenta completar una vez cada paso de un formulario reconocido. Solo se completan formularios de primer nivel HTTPS en el host exacto mipersonal.personal.com.ar, con acción en el mismo origen y botón reconocido. Los demás dominios/formularios requieren revisión manual; ampliar la lista exige verificar antes el destino real. Los selectores son conservadores, NO han sido confirmados con el portal real.

Se persiste una pausa antes de evaluar el ingreso para impedir repetir automáticamente contraseñas tras la muerte del proceso o un fallo. Ante código/captcha/rechazo detectado, se detiene la recuperación. Abrir Personal y conseguir un saldo válido, o volver a guardar el acceso, habilita nuevos intentos. El saldo y su fecha solo cambian al leer un saldo válido de la misma línea.

## Validación y límites
Compilación Android API 35, versión 11/0.11 y firma APK verificadas. Misma clave debug del respaldo 0.10. LoginChecks.cjs prueba pasos de mail/contraseña, origen, formulario, bloqueo y límites de intentos con DOM simulado. No hubo emulador ni teléfono conectado; no se probó AndroidKeyStore en dispositivo ni el ingreso real, vencimiento o ejecución nocturna. El intento HTTP al portal desde este entorno no logró acceso. Por tanto, NO afirmar que la reconexión a Personal ya funciona.

No se publicó en GitHub ni se modificó el feed remoto. Actualizar manualmente mediante la APK adjunta. El zip contiene la clave de desarrollo previa: mantener privado y no publicar.
