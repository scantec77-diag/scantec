# MisGigas 0.8 — registro de entrega

Fecha: 12/11/2026, Argentina.

## Implementado
- Widget redimensionable en ambos ejes; mínimo 150 × 150 dp. Se actualiza al cambiar el tamaño. El launcher decide la grilla final.
- Texto blanco, en negrita, renderizado a mayor resolución. Muestra GB restantes y GB del plan en lugar del porcentaje.
- Color por GB absolutos, interpolado continuamente: rojo en 0 GB, amarillo en 5 GB y verde desde 15 GB. Esos umbrales iniciales pueden cambiarse a distancia.
- Arco con gradiente visible; su longitud sigue representando la proporción disponible del plan.
- Botón independiente Buscar actualización. Cuando se detecta una versión nueva dice Actualizar y su versión.
- Consulta de actualizaciones al abrir la app (límite de una consulta por diez minutos), al habilitar un widget y cada 30 minutos aproximadamente con JobScheduler. Android puede demorar las consultas de fondo.
- Ajustes de colores y umbrales descargables, aplicados sin instalar otra APK. Se conserva la última configuración si no hay conexión.
- Descarga de futuras APK al tocar Actualizar; verifica SHA-256, nombre del paquete, versión y la misma firma antes de abrir el instalador Android.
- Android puede solicitar Permitir desde esta fuente y confirmación de instalación. No se evaden verificaciones ni Play Protect.
- Compilación debug 0.8, versión Android 8, misma clave de desarrollo incluida en el respaldo de la 0.7.

## Canal publicado
https://raw.githubusercontent.com/scantec77-diag/scantec/misgigas-updates/misgigas/updates.json
Rama dedicada misgigas-updates del repositorio scantec77-diag/scantec. Solo se publicaron la APK y el JSON, sin subir la clave de firma.

## Validado
Compilación nativa con SDK 35; verificación de firma APK v3; metadatos paquete/versión/debug; comprobaciones Java de interpolación, continuidad en umbrales, valores inválidos y proporción del arco. Canal público y descarga APK comprobados: archivo idéntico al compilado, con SHA-256 coincidente.

## Pendiente de prueba en el Samsung
Instalar 0.8 encima sin desinstalar. Revisar redimensión, legibilidad y gradiente. Si el launcher conserva las restricciones viejas, quitar solo el widget y agregarlo nuevamente. Confirmar sincronización de apariencia y botón Buscar actualización (con la 0.8 vigente debe informar que ya está actualizado). La instalación de una versión posterior solo podrá probarse cuando exista una APK nueva firmada. No se usó emulador ni teléfono físico en esta entrega.

## Cómo publicar la siguiente actualización
Para cambios de apariencia, editar style y aumentar styleRevision en updates.json; no tocar versionCode ni hash de la APK vigente. Campos admitidos: red/yellow/green/text como #RRGGBB, lowGb y highGb positivos, highGb mayor que lowGb.
Para otra APK, mantener applicationId ar.ari.gigas y la misma clave; incrementar versionCode en app/build.gradle, build_manual.py y VERSION en UpdateManager.java; actualizar las etiquetas de versión y nombre de salida. Publicar la nueva APK en misgigas/ de la rama y actualizar versionCode, versionName, apkUrl y sha256 del JSON. No publicar la clave de desarrollo. El hash evita aceptar descargas truncadas y la comparación de certificado exige la firma de esta aplicación.

## Continuidad
La 0.7 no tenía actualizador remoto. La instalación inicial de la 0.8 es necesaria para agregarlo. El actualizador no instala en silencio. Cambios nativos siguen requiriendo APK; colores y umbrales preparados se actualizan por JSON.
