# MisGigas 0.10

Estado actual en REGISTRO_0.10.md. Historial a continuación.

# MisGigas 0.9

Estado actual en REGISTRO_0.9.md. Registro anterior a continuación.

# MisGigas 0.8

Ver REGISTRO_0.8.md para el estado actual. Lo siguiente es el registro histórico de 0.7 y anteriores.

# MisGigas 0.7 · widget Personal

## Cambio visual

El widget se separa del panel administrativo: tarjeta oscura con bordes redondeados, arco semicircular que representa la proporción de datos restantes, saldo grande, porcentaje y última lectura. La flecha circular solicita la consulta y tocar el saldo abre la administración. Oculta del widget el formulario, el desglose completo y los accesos adicionales.

El arco se reduce al bajar los GB disponibles y aumenta si se agregan datos o se renueva el plan. Usa verde agua, ámbar por debajo del 20% y coral por debajo del 10%. En caso de error conserva la lectura e indica que no se pudo actualizar; el detalle está dentro de la app.

Se mantiene la sincronización experimental implementada en 0.6 y el intervalo solicitado de quince minutos, sujeto a Android. Claro no cambia. No se incorporan notificaciones sonoras.

Instalar como actualización sin desinstalar. Si el launcher conserva el tamaño grande del widget anterior, redimensionarlo o quitarlo y agregarlo de nuevo. La composición nativa se debe comprobar en el teléfono: este entorno no dispone de emulador ni adb. La APK se compiló y se verificó su firma.

## Historial 0.6

# MisGigas 0.6 · prueba Personal

## Cambios de esta versión

- Personal: lectura automática de «Datos para todo uso», incluyendo total y GB disponibles. Calcula consumidos y porcentaje disponible.
- Primer acceso al portal: vincula la línea identificada y guarda el saldo sin el selector de coincidencias. Rechaza otra línea y páginas ambiguas.
- Widget centrado en Personal con barra, cifras, hora de última lectura, flecha de consulta y acceso al portal.
- Consulta periódica con JobScheduler: intervalo 15 minutos, ventana flexible de 5 minutos, requiere red; persiste tras reiniciar.
- La flecha solicita un trabajo inmediato (expeditado desde Android 12, sujeto a cuotas y decisiones del sistema). No necesita mantener la app abierta.
- Cada trabajo abre un lector web sin ventana visible y usa las cookies y almacenamiento web existentes de la app. No se implementó ni se presume una API privada de Personal.
- Lectura limitada a 75 segundos. Si falla, conserva el saldo y la fecha de la última lectura correcta. No emite sonido ni notificaciones.
- Claro conserva el comportamiento manual de la versión anterior. No se incorporó su sincronización automática.

## Prueba en el teléfono

1. Instalar la APK como actualización de la 0.5, sin desinstalar para conservar sesión y preferencias. Si Android rechaza la actualización, no borrar los datos: revisar el mensaje.
2. Abrir Mi Personal dentro de MisGigas y esperar a que aparezca «Datos para todo uso» junto con la línea. Si caducó la sesión, iniciar sesión en el propio portal.
3. La lectura correcta debe guardar total, restantes, consumidos y porcentaje automáticamente. «Importar» permite reintentar sin elegir textos.
4. Agregar el widget desde la aplicación o el menú de inicio. Si el anterior quedó pequeño, ampliarlo o volver a agregarlo.
5. Pulsar ↻: debe solicitar la consulta sin abrir la configuración. Al terminar, debe cambiar la hora; un saldo igual con hora nueva es válido.
6. Salir de la app y probar nuevamente desde el widget. Luego apagar la pantalla y revisar la hora después del siguiente período. Android puede demorarla.
7. Sin conexión: pulsar ↻ y comprobar que muestra el aviso, manteniendo la lectura anterior.

## Límites y validación

Compilación y firma de APK verificadas con Android SDK 35. Pasaron 20 pruebas JVM del parser y cálculos, y las comprobaciones previas de calendario y unidades. No hay emulador/adb en este entorno: no se validó la interfaz nativa ni una consulta autenticada real en Android.

La sincronización en segundo plano es experimental: depende de que Personal permita reutilizar la sesión en otro WebView de la misma app, de la estructura de su página y de que pueda cargar sin ventana visible. Una sesión guardada solo en memoria o sessionStorage podría requerir otra solución. El teléfono debe confirmar este comportamiento; la implementación no demuestra por sí sola que funcione.

Quince minutos es la frecuencia solicitada, no un plazo garantizado. Ahorro de batería, Doze, restricciones de Android/Samsung, falta de red y cuotas pueden retrasar tanto el trabajo periódico como el solicitado manualmente. «Forzar detención» impide la ejecución hasta volver a abrir la app. La fecha visible corresponde a la última lectura correcta del portal, no a una medición instantánea de tráfico.

La lectura requiere identificar la línea y la tarjeta general; si cambia el formato o aparece otra línea, falla sin sobrescribir. No usa OCR, accesibilidad ni Shizuku para esta función. La fecha de renovación se toma del portal cuando está disponible.

## Compilar y comprobar

`ANDROID_HOME=/ruta/al/sdk python3 build_manual.py`

El script requiere build-tools 35.0.0 y platforms/android-35. Conserva la clave de desarrollo usada en 0.5; no es una firma de Play Store.

Pruebas del parser (desde la raíz del proyecto):

```
mkdir -p test-classes
java com.sun.tools.javac.Main -d test-classes app/src/main/java/ar/ari/gigas/PersonalBalance.java checks/PersonalChecks.java
java -cp test-classes ar.ari.gigas.PersonalChecks
```

## Historial hasta 0.5

# Mis Gigas 0.3 — prueba individual de Personal

APK compilada y firmada con la misma clave de desarrollo que 0.2. Puede instalarse encima conservando datos. Versión 3. No probada en un Samsung real ni con Shizuku real. No se afirma compatibilidad hasta ejecutar esta prueba en el dispositivo.

## Prueba
1. Abrir Probar consumo individual de Personal.
2. Detectar SIM y conceder permiso Teléfono. Seleccionar la SIM Personal por su nombre/ranura.
3. Habilitar Acceso al uso y tocar Comprobar acceso individual.
4. Si está bloqueado, instalar e iniciar Shizuku desde https://shizuku.rikka.app/download/ siguiendo https://shizuku.rikka.app/guide/setup/ (Android 11+: Wi-Fi y depuración inalámbrica). Volver a Mis Gigas, Autorizar auxiliar Shizuku y Comprobar acceso individual. Reiniciar Shizuku puede ser necesario después de reiniciar el teléfono.
5. Si la lectura funciona, verificar que la SIM elegida sea Personal y que el saldo manual guardado sea actual. Tocar Iniciar descuento de Personal y confirmar.
6. Mantener la pantalla de prueba abierta. Consulta cada 15 segundos; Android puede actualizar estadísticas con demora. La prueba se pausa al salir de esta pantalla o apagarla. No es monitoreo continuo en segundo plano.
7. Con Wi-Fi apagado y Personal elegida como SIM de datos, generar algo de tráfico normal, volver a mirar el contador y compararlo con Ajustes usando el mismo período. Luego generar tráfico con Claro y verificar que el contador individual de Personal no aumente por ese tráfico. Desactivar temporalmente el cambio automático de SIM de datos facilita esta prueba. Estos cambios de conexión se hacen manualmente desde Ajustes.

## Qué implementa
- Detección de SIM por SubscriptionManager, selección explícita y lectura filtrada por subscriberId no vacío.
- Dos vías: llamada normal y servicio de usuario Shizuku con identidad shell; no se conceden permisos privilegiados directamente a Mis Gigas.
- El auxiliar intenta leer identificador y estadísticas de la SIM seleccionada usando el contexto de com.android.shell. Puede fallar según Android/Samsung y se informa sin modificar el saldo.
- El identificador real se usa internamente y no se devuelve, registra o guarda. Se compara una huella SHA-256 local para detectar cambio de SIM. El auxiliar devuelve solo contador, subId, fecha y huella.
- Sin fallback al total conjunto en la prueba Personal. El listado general anterior continúa mostrando ambas SIM y se rotula como tal.
- Saldo estimado = saldo inicial menos diferencia del contador individual desde calibración. Se detiene ante retroceso de contador, cambio de identidad/SIM, permiso insuficiente o error. Cancelar o salir invalida respuestas pendientes. Saldo mínimo cero.
- No ajusta promociones, gigas sin cargo o diferencias con el operador. No modifica el saldo de Claro. El widget muestra la estimación guardada y su origen.
- Conserva los portales experimentales 0.2, sin corregir aún el bloqueo de inicio de sesión reportado en Personal. No hay sincronización oficial de cuentas ni actualizador automático.

## Verificaciones ejecutadas
Compilación Java, empaquetado AAPT2/D8, firma APK y comparación de certificado con 0.2. Pruebas de descuento de 0.25 GB, contador estable, límite cero y retroceso bloqueado. XML válido. Pendientes: instalación, permisos, servicio Shizuku en Android 17, estadísticas individuales reales, latencia, cambio de SIM y uso cotidiano en Samsung.

## Compilación y dependencias
Android SDK/Build Tools 35, Java 17+. ANDROID_HOME debe señalar al SDK; ejecutar python3 build_manual.py. Incluye Shizuku API/provider/aidl/shared 13.1.5 en vendor, licencia MIT adjunta; no incluye la app Shizuku. El servicio de usuario queda limitado al UID de Mis Gigas y se libera al destruir la pantalla. Clave de desarrollo en dev-signing: solo para continuidad de las pruebas, no para producción.

## Referencias
https://github.com/RikkaApps/Shizuku-API
https://developer.android.com/reference/android/app/usage/NetworkStatsManager
https://developer.android.com/reference/android/telephony/TelephonyManager

---
Notas de la base anterior:
# Mis Gigas 0.2 — APK de pruebas

APK compilada y firmada con clave de desarrollo. Compilación, firma, manifiesto y pruebas de calendario/unidades verificados. No probada en un teléfono ni con cuentas reales. Requiere Android 10 o posterior.

## Uso
1. Instalar MisGigas_v0.2_pruebas.apk.
2. Configurar GB totales, GB restantes y día de renovación de cada línea. Guardar.
3. Usar Agregar widget o el menú Widgets de la pantalla de inicio.
4. Para consumo por aplicación: habilitar Acceso al uso y consultar el período deseado.
5. Para probar cuentas: Consultar cuenta Claro/Personal, iniciar sesión en el portal oficial, navegar al saldo y tocar Importar saldo. Elegir el valor RESTANTE y confirmar la línea y el importe. La app busca cantidades en GB en el texto visible: puede encontrar ofertas, GB consumidos u otras líneas. La confirmación del usuario es obligatoria.

## Límites actuales
- La consulta de portales es experimental; el inicio de sesión puede rechazar WebView o requerir códigos. No se ha validado con cuentas reales. Navegador permite abrir el portal fuera de la app; su sesión no se importa de regreso.
- Sin sincronización automática, sin renovación automática de saldos. Cada dato muestra su fecha y origen: manual o importado y confirmado. No se presenta como consulta oficial en tiempo real.
- Los días se calculan con el día de renovación configurado por el usuario, no se importan del portal.
- Android limita subscriberId; consumo total y por UID de ambas SIM juntos. No atribuir ese consumo a una línea. No es el saldo oficial ni descuenta promociones sin cargo.
- Las aplicaciones pueden aparecer como UID por las restricciones de visibilidad. UID compartidos se agrupan.
- El widget solicita actualización cada 30 minutos y se actualiza al guardar, pero Android puede demorar tareas. Esa actualización solo vuelve a mostrar los datos guardados.

## Privacidad
Inicio de sesión dentro de una WebView HTTPS. No hay formulario propio de contraseñas ni puente JavaScript nativo. No se leen inputs, cookies o tokens para importar. Los datos de sesión los conserva WebView en el dispositivo y se excluyen de copias de seguridad. La importación lee texto visible únicamente en dominios de la compañía seleccionada y pide confirmación. No existe un backend propio.

## Compilación
El proyecto Gradle usa Android Gradle Plugin 8.9.2, Gradle 8.11.1, JDK 17+ y SDK 35. No incluye wrapper. En este entorno Gradle no pudo resolver el plugin remoto. Se compiló con aapt2, compilador Java, D8, zipalign y apksigner de Android Build Tools 35.0.0. Ver build_manual.py.
La carpeta dev-signing conserva una clave Android de desarrollo para reproducir actualizaciones de esta prueba; no usar como firma de producción. Alias androiddebugkey, contraseñas android.

## Validación pendiente en Samsung
Instalación; agregado/redimensión del widget; permiso de uso y su revocación; comparación con Ajustes usando el mismo período; acceso real a los dos portales; importación de saldo correcto; expiración de sesión; navegación y teclado; ahorro de batería.

Referencia: https://developer.android.com/reference/android/app/usage/NetworkStatsManager


## Prueba 0.4: acceso Mi Personal
Botón principal para abrir https://mipersonal.personal.com.ar/ dentro de MisGigas. Sesión web propia, independiente de Chrome. Recargar y abrir navegador como alternativa. La barra muestra solo el dominio, sin parámetros de autenticación. No requiere Shizuku para acceder al portal. La importación existente sigue siendo opcional y confirmada; no hay sincronización automática. Probar inicio de sesión y visualización de GB en el teléfono; no verificados con una cuenta real durante la compilación.

## Prueba 0.5: contenido borroso en WebView
Ajustes de viewport, agente de navegador y cookies para compatibilidad con el portal. WebChromeClient y ventanas HTTPS iniciadas por el usuario dirigidas al visor interno. Barra compacta. No se eliminan capas de la página ni se omiten controles de acceso. Compilación y firma verificadas; el resultado con sesión real requiere prueba en el dispositivo.
