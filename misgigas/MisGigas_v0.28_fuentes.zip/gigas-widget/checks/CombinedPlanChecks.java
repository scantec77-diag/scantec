package ar.ari.gigas;
public class CombinedPlanChecks {
 public static void main(String[] args) {
  if(Math.abs(CombinedPlanGauge.ratio(40,24.5f)-.6125)>1e-6)throw new AssertionError("Personal denominator");
  if(Math.abs(CombinedPlanGauge.ratio(20,16.6f)-.83)>1e-6)throw new AssertionError("Claro denominator");
  if(CombinedPlanGauge.ratio(40,0)!=0||CombinedPlanGauge.ratio(20,20)!=1)throw new AssertionError("Empty/full plan");
  for(float[] input:new float[][]{{0,0},{20,-1},{20,21},{Float.NaN,10},{20,Float.POSITIVE_INFINITY}})
   if(!Double.isNaN(CombinedPlanGauge.ratio(input[0],input[1])))throw new AssertionError("Invalid reading");
  if(!CombinedPlanGauge.value(20,16.6f).equals("16,60 GB")||!CombinedPlanGauge.value(0,0).equals("—"))throw new AssertionError("Labels");
  System.out.println("PASS: independent plans, empty/full, unknown/invalid readings and GB labels");
 }
}
