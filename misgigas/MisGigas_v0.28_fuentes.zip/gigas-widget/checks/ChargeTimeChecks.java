package ar.ari.gigas;
public class ChargeTimeChecks {
 static void eq(String actual,String expected){if(!actual.equals(expected))throw new AssertionError(actual+" != "+expected);}
 public static void main(String[] a){
  eq(ChargeTime.text(false,false,1000),"");eq(ChargeTime.text(false,true,0),"");
  eq(ChargeTime.text(true,true,-1),"Carga completa");
  eq(ChargeTime.text(true,false,-1),"Hasta el 100 % · calculando…");
  eq(ChargeTime.text(true,false,1),"Hasta el 100 % · ≈ 1 min");
  eq(ChargeTime.text(true,false,32*60000),"Hasta el 100 % · ≈ 32 min");
  eq(ChargeTime.text(true,false,3599999),"Hasta el 100 % · ≈ 1 h");
  eq(ChargeTime.text(true,false,61*60000),"Hasta el 100 % · ≈ 1 h 1 min");
  System.out.println("PASS: unplugged, full, unknown estimate, minutes and hours");
 }
}
