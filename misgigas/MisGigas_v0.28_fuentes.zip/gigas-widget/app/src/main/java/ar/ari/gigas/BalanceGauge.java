package ar.ari.gigas;
import android.content.Context;import android.graphics.*;import java.util.Locale;
/** Standalone carrier widgets use the same horizontal bars as the dashboard. */
final class BalanceGauge {
 static Bitmap draw(Context c,float total,float left,boolean configured,int width){return draw(c,total,left,configured,width,"Personal");}
 static Bitmap draw(Context c,float total,float left,boolean configured,int width,String carrier){
  double ratio=configured?CombinedPlanGauge.ratio(total,left):Double.NaN;boolean ok=Double.isFinite(ratio);
  BarData data=new BarData(carrier,ok?String.format(new Locale("es","AR"),"%.2f GB",left):"—",ok?String.format(new Locale("es","AR"),"Restantes de %.2f GB",total):"Conectá tu línea "+carrier,ratio);
  Bitmap b=Bitmap.createBitmap(width,GaugeResolution.height(width),Bitmap.Config.ARGB_8888);b.setDensity(Bitmap.DENSITY_NONE);Canvas canvas=new Canvas(b);float unit=width/360f;canvas.translate(0,Math.max(0,(b.getHeight()-78*unit)/2));DashboardGauge.paint(canvas,width,b.getHeight(),unit,unit,data,ratio);return b;
 }
}
