package ar.ari.gigas;
import android.app.*;import android.app.usage.*;import android.content.*;import android.graphics.Color;import android.graphics.Typeface;import android.graphics.drawable.GradientDrawable;import android.net.ConnectivityManager;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;import java.util.*;
public class DashboardActivity extends Activity {
 LinearLayout root;Button update;TextView balances,chargeTime;BarMeter pbar,cbar,bbar,wbar,sbar,chargebar;LinearLayout chargeGroup;Handler h=new Handler(Looper.getMainLooper());boolean active=false,reading=false;final BroadcastReceiver batteryEvents=new BroadcastReceiver(){public void onReceive(Context c,Intent i){if(active){readBattery();DashboardWidget.request(c);}}};
 final int ink=0xffe9f0fc,muted=0xffa5b7d0; final Runnable tick=new Runnable(){public void run(){if(!active)return;render();updateButton();h.postDelayed(this,3000);}};
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xff0b1324);getWindow().setNavigationBarColor(0xff0b1324);ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xff0b1324);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(18),dp(14),dp(18),dp(18));scroll.addView(root);setContentView(scroll);
 label(root,"MI TABLERO",25,true);label(root,"Mis Gigas 0.28 · conexiones y batería",13,false);
 LinearLayout bat=card(root,false);bbar=meter(bat);chargeGroup=new LinearLayout(this);chargeGroup.setOrientation(1);bat.addView(chargeGroup);chargebar=meter(chargeGroup);chargeTime=label(chargeGroup,"",13,false);chargeGroup.setVisibility(View.GONE);
 label(root,"DATOS DISPONIBLES",12,false);LinearLayout claroCard=card(root,false);cbar=meter(claroCard);LinearLayout personalCard=card(root,false);pbar=meter(personalCard);balances=label(root,"",11,false);
 label(root,"CONSUMO DE HOY",12,false);LinearLayout wifiCard=card(root,false);wbar=meter(wifiCard);LinearLayout sharedCard=card(root,false);sbar=meter(sharedCard);
 LinearLayout actions=new LinearLayout(this);root.addView(actions);button(actions,"↻ Actualizar",()->{PersonalJobs.now(this);ClaroJobs.now(this);render();},true);button(actions,"Configurar",()->startActivity(new Intent(this,MainActivity.class)),true);
 update=new Button(this);update.setTextSize(14);root.addView(update,new LinearLayout.LayoutParams(-1,-2));update.setOnClickListener(v->startActivity(new Intent(this,UpdateActivity.class)));updateButton();
 button(root,"Agregar widget Mi Tablero",()->{android.appwidget.AppWidgetManager m=android.appwidget.AppWidgetManager.getInstance(this);if(m.isRequestPinAppWidgetSupported())m.requestPinAppWidget(new ComponentName(this,DashboardWidget.class),null,null);else Toast.makeText(this,"Mantené apretado el inicio → Widgets → Mis Gigas · Mi Tablero",1).show();},false);
 button(root,"Permitir lectura de consumo",()->startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)),false);
 }
 void updateButton(){if(update!=null){boolean available=UpdateManager.hasUpdate(this);update.setText(available?"● Actualizar a "+Plan.prefs(this).getString("updateName",""):"Buscar actualización · versión "+UpdateManager.versionName(this));update.setTextColor(available?0xfff45b69:0xff26364d);}}
 int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
 TextView label(LinearLayout into,String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(bold?ink:muted);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(0,dp(3),0,dp(3));into.addView(t);return t;}
 LinearLayout card(LinearLayout into,boolean weighted){LinearLayout v=new LinearLayout(this);v.setOrientation(1);v.setPadding(dp(12),dp(10),dp(12),dp(10));GradientDrawable bg=new GradientDrawable();bg.setColor(0xff15233a);bg.setCornerRadius(dp(16));v.setBackground(bg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(weighted?0:-1,-2,weighted?1:0);lp.setMargins(dp(3),dp(6),dp(3),dp(6));into.addView(v,lp);return v;}
 BarMeter meter(LinearLayout into){BarMeter v=new BarMeter(this);into.addView(v,new LinearLayout.LayoutParams(-1,-2));return v;}
 void button(LinearLayout into,String text,Runnable run,boolean weight){Button b=new Button(this);b.setText(text);b.setTextSize(13);into.addView(b,new LinearLayout.LayoutParams(weight?0:-1,-2,weight?1:0));b.setOnClickListener(v->run.run());}
 void render(){pbar.set(BarData.plan(this,"personal","Personal"));cbar.set(BarData.plan(this,"claro","Claro"));android.content.SharedPreferences p=Plan.prefs(this);balances.setText("Personal: "+DashboardWidget.time(this,p.getLong("personalstamp",0))+" · Claro: "+DashboardWidget.time(this,p.getLong("clarostamp",0)));readBattery();if(System.currentTimeMillis()-lastNet>=30000&&!reading)readNetwork();}
 void readBattery(){BatterySnapshot.Snapshot s=BatterySnapshot.read(this);bbar.set(BarData.battery(s));boolean wasVisible=chargeGroup.getVisibility()==View.VISIBLE;
  if(s.connected){chargeGroup.setVisibility(View.VISIBLE);chargebar.set(BarData.charge(s));chargeTime.setText(ChargeTime.text(true,s.full,s.chargeTimeMillis));if(!wasVisible&&android.animation.ValueAnimator.areAnimatorsEnabled()){chargeGroup.setAlpha(0f);chargeGroup.setTranslationY(dp(-6));chargeGroup.animate().alpha(1f).translationY(0).setDuration(220).start();}}
  else{chargeGroup.animate().cancel();chargebar.stop();chargeGroup.setVisibility(View.GONE);chargeGroup.setAlpha(1);chargeGroup.setTranslationY(0);chargeTime.setText("");}
  wbar.set(BarData.network(this,"dashWifiBytes","Wi-Fi"));sbar.set(BarData.network(this,"dashSharedBytes","Wi-Fi compartido"));}

 long lastNet=0;
 String format(long b){return BatterySnapshot.num(b/1e9,"GB");}
 void readNetwork(){reading=true;lastNet=System.currentTimeMillis();new Thread(()->{DashboardWidget.network(this);runOnUiThread(()->{reading=false;if(!isDestroyed()){readBattery();}});}).start();}
 protected void onResume(){super.onResume();active=true;UpdateJobs.ensure(this);UpdateManager.checkAsync(this);updateButton();registerReceiver(batteryEvents,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));PersonalJobs.ensure(this);ClaroJobs.ensure(this);h.post(tick);}
 protected void onPause(){DashboardWidget.request(this);active=false;for(BarMeter m:new BarMeter[]{pbar,cbar,bbar,wbar,sbar,chargebar})m.settle();chargeGroup.animate().cancel();unregisterReceiver(batteryEvents);h.removeCallbacks(tick);super.onPause();}
}
