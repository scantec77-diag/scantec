package ar.ari.gigas;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
/** Renders at physical screen resolution without upscaled raster images. */
final class BarMeter extends View {
 private BarData data=new BarData("","","",Double.NaN);private double shown=Double.NaN,target=Double.NaN;private ValueAnimator animator;
 BarMeter(Context c){super(c);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);}
 void set(BarData next){data=next;setContentDescription(next.label+", "+next.value+", "+next.sub);double to=next.ratio;
  if(Double.compare(target,to)==0){invalidate();return;}target=to;stop();
  if(!Double.isFinite(to)||!isAttachedToWindow()||!isShown()||!ValueAnimator.areAnimatorsEnabled()){shown=to;invalidate();return;}
  float from=Double.isFinite(shown)?(float)shown:0;animator=ValueAnimator.ofFloat(from,(float)to);animator.setDuration(450);animator.setInterpolator(new DecelerateInterpolator());animator.addUpdateListener(a->{shown=(float)a.getAnimatedValue();invalidate();});animator.start();
 }
 void stop(){if(animator!=null){animator.cancel();animator=null;}}
 void settle(){stop();shown=target;invalidate();}
 protected void onDetachedFromWindow(){settle();super.onDetachedFromWindow();}
 protected void onDraw(Canvas c){super.onDraw(c);DashboardGauge.paint(c,getWidth(),getHeight(),getResources().getDisplayMetrics().density,getResources().getDisplayMetrics().scaledDensity,data,shown);}
 protected void onMeasure(int w,int h){setMeasuredDimension(MeasureSpec.getSize(w),resolveSize((int)(82*getResources().getDisplayMetrics().scaledDensity),h));}
}
