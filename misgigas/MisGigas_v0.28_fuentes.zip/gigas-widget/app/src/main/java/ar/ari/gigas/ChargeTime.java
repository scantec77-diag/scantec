package ar.ari.gigas;
final class ChargeTime {
 static String text(boolean connected,boolean full,long millis){
  if(!connected)return "";
  if(full)return "Carga completa";
  if(millis<0)return "Hasta el 100 % · calculando…";
  long minutes=Math.max(1,millis/60000+(millis%60000>0?1:0));
  return "Hasta el 100 % · ≈ "+(minutes>=60?minutes/60+" h"+(minutes%60>0?" "+minutes%60+" min":""):minutes+" min");
 }
}
