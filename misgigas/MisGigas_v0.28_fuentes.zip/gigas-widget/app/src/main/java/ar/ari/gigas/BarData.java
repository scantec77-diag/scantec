package ar.ari.gigas;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.Locale;
final class BarData {
 final String label,value,sub; final double ratio; final boolean consumption;
 BarData(String label,String value,String sub,double ratio){this(label,value,sub,ratio,false);}
 BarData(String label,String value,String sub,double ratio,boolean consumption){this.label=label;this.value=value;this.sub=sub;this.ratio=ratio;this.consumption=consumption;}
 static final Locale ES=new Locale("es","AR");
 static BarData plan(Context c,String key,String name){SharedPreferences p=Plan.prefs(c);float total=p.getFloat(key+"total",0),left=p.getFloat(key+"left",-1);double r=CombinedPlanGauge.ratio(total,left);boolean ok=Double.isFinite(r);return new BarData(name,ok?String.format(ES,"%.2f GB",left):"—",ok?String.format(ES,"Restantes de %.2f GB",total):"Sin lectura",r);}
 static BarData network(Context c,String key,String label){long bytes=Plan.prefs(c).getLong(key,-1);if(bytes<0)return new BarData(label,"—","Sin lectura disponible",Double.NaN,true);double gb=bytes/1e9;double base=Math.pow(10,Math.floor(Math.log10(Math.max(.1,gb))));double n=gb/base,top=(n<=1?1:n<=2?2:n<=5?5:10)*base;return new BarData(label,String.format(ES,"%.3f GB",gb),String.format(ES,"Hoy · escala auto 0–%.1f GB",top),gb/top,true);}
 static BarData battery(BatterySnapshot.Snapshot s){return new BarData("Batería restante",s.percent>=0?s.percent+" %":"—",s.state,s.percent>=0?s.percent/100.0:Double.NaN);}
 static BarData charge(BatterySnapshot.Snapshot s){return new BarData("Potencia de carga",Double.isFinite(s.chargingWatts)?BatterySnapshot.num(s.chargingWatts,"W"):"—","Neta estimada · 0–45 W",ChargePower.ratio(s.chargingWatts));}
}
