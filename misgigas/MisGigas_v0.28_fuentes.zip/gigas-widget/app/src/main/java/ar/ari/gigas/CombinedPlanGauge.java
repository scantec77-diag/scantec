package ar.ari.gigas;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import java.util.Locale;

/** Both plans retain their own denominator; balances are never added together. */
final class CombinedPlanGauge {
 static final Locale LOCALE = new Locale("es", "AR");
 static double ratio(float total, float left) {
  return Float.isFinite(total) && Float.isFinite(left) && total > 0 && left >= 0 && left <= total
   ? (double) left / total : Double.NaN;
 }
 static String value(float total, float left) {
  return Double.isFinite(ratio(total,left)) ? String.format(LOCALE,"%.2f GB",left) : "—";
 }
 static String summary(float total,float left) {
  double r=ratio(total,left);
  return Double.isFinite(r)?String.format(LOCALE,"%.0f %% · de %.2f GB",100*r,total):"Sin lectura";
 }
 static Bitmap draw(Context context) {
  SharedPreferences prefs=Plan.prefs(context);
  return draw(prefs.getFloat("personaltotal",0),prefs.getFloat("personalleft",-1),
   prefs.getFloat("clarototal",0),prefs.getFloat("claroleft",-1));
 }
 static Bitmap draw(float pt,float pl,float ct,float cl) {
  Bitmap b=Bitmap.createBitmap(720,312,Bitmap.Config.ARGB_8888);b.setDensity(Bitmap.DENSITY_NONE);Canvas c=new Canvas(b);
  DashboardGauge.paint(c,720,156,2,2,new BarData("Personal",value(pt,pl),summary(pt,pl),ratio(pt,pl)),ratio(pt,pl));
  c.translate(0,156);DashboardGauge.paint(c,720,156,2,2,new BarData("Claro",value(ct,cl),summary(ct,cl),ratio(ct,cl)),ratio(ct,cl));return b;
 }
 static void text(Canvas canvas,Paint paint,String text,float x,float y,float size,int color,
  boolean bold,Paint.Align align,float maxWidth) {
  paint.setStyle(Paint.Style.FILL);paint.setColor(color);paint.setTextAlign(align);
  paint.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));paint.setTextSize(size);
  while(paint.measureText(text)>maxWidth&&paint.getTextSize()>18)paint.setTextSize(paint.getTextSize()-1);
  canvas.drawText(text,x,y,paint);
 }
}
