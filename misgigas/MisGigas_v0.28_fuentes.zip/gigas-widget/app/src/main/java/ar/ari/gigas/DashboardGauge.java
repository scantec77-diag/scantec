package ar.ari.gigas;
import android.graphics.*;
/** Horizontal meters: direct Canvas drawing in the app, bounded HD bitmaps in RemoteViews. */
final class DashboardGauge {
 static void paint(Canvas c,int width,int height,float density,float textScale,BarData d,double ratio){
  android.text.TextPaint p=new android.text.TextPaint(Paint.ANTI_ALIAS_FLAG|Paint.SUBPIXEL_TEXT_FLAG);p.setDither(true);
  float left=2*density,right=width-2*density,baseline=25*textScale;
  p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setColor(0xffa7b5c7);p.setTextSize(13*textScale);
  p.setTextAlign(Paint.Align.LEFT);p.setTextSize(19*textScale);float valueWidth=p.measureText(d.value);p.setTextSize(13*textScale);String label=android.text.TextUtils.ellipsize(d.label,p,Math.max(0,right-left-valueWidth-12*density),android.text.TextUtils.TruncateAt.END).toString();c.drawText(label,left,baseline,p);
  p.setTextSize(19*textScale);p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setColor(0xffedf2f8);p.setTextAlign(Paint.Align.RIGHT);c.drawText(d.value,right,baseline,p);
  float y=baseline+13*density,h=8*density;RectF track=new RectF(left,y,right,y+h);p.setColor(0xff303d4d);c.drawRoundRect(track,h/2,h/2,p);
  if(Double.isFinite(ratio)&&ratio>0){float end=left+(right-left)*(float)Math.max(0,Math.min(1,ratio));int[] colors=d.consumption?new int[]{0xff4ce5a2,0xffffd34d,0xffff913e,0xfff45b69}:new int[]{0xfff45b69,0xffff913e,0xffffd34d,0xff4ce5a2};p.setShader(new LinearGradient(left,0,right,0,colors,null,Shader.TileMode.CLAMP));c.save();c.clipRect(left,y,end,y+h);c.drawRoundRect(track,h/2,h/2,p);c.restore();p.setShader(null);}
  p.setTextAlign(Paint.Align.LEFT);p.setTypeface(Typeface.DEFAULT);p.setColor(0xffa7b5c7);p.setTextSize(11*textScale);c.drawText(android.text.TextUtils.ellipsize(d.sub,p,right-left,android.text.TextUtils.TruncateAt.END).toString(),left,y+h+18*textScale,p);
 }
 static Bitmap bitmap(android.content.Context context,BarData d){android.util.DisplayMetrics metrics=context.getResources().getDisplayMetrics();int budgetWidth=(int)Math.sqrt(Math.max(1,(double)metrics.widthPixels*metrics.heightPixels)*1.2/(6*78.0/360));int width=Math.max(1,Math.min(1920,Math.min(metrics.widthPixels,budgetWidth)));float unit=width/360f;int height=Math.round(78*unit);Bitmap b=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);b.setDensity(Bitmap.DENSITY_NONE);paint(new Canvas(b),width,height,unit,unit,d,d.ratio);return b;}
 static Bitmap plan(android.content.Context c,String key,String name){return bitmap(c,BarData.plan(c,key,name));}
 static Bitmap network(android.content.Context c,String key,String name){return bitmap(c,BarData.network(c,key,name));}
 static Bitmap battery(android.content.Context c,BatterySnapshot.Snapshot s){return bitmap(c,BarData.battery(s));}
 static Bitmap charge(android.content.Context c,BatterySnapshot.Snapshot s){return bitmap(c,BarData.charge(s));}
}
