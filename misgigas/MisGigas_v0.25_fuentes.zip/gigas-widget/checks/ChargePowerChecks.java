package ar.ari.gigas;
public class ChargePowerChecks {
 static void eq(double actual, double expected) {
  if (Math.abs(actual - expected) > 1e-9 || !Double.isFinite(actual)) throw new AssertionError(actual + " != " + expected);
 }
 public static void main(String[] args) {
  eq(ChargePower.watts(2, 4500, 5000000), 22.5);
  eq(ChargePower.ratio(22.5), .5);
  eq(ChargePower.ratio(45), 1);
  eq(ChargePower.ratio(0), 0);
  eq(ChargePower.ratio(60), 1);
  eq(ChargePower.watts(2, 4500, 12000000), 54); // Value is not clipped with the arc.
  eq(ChargePower.watts(0, 4500, 5000000), 0);
  eq(ChargePower.watts(2, 4500, -5000000), 0); // Discharge must not appear as charge.
  if (!Double.isNaN(ChargePower.watts(2, -1, 5000000)) || !Double.isNaN(ChargePower.watts(2, 4500, Integer.MIN_VALUE)) || !Double.isNaN(ChargePower.ratio(Double.NaN))) throw new AssertionError("Missing reading");
  System.out.println("PASS: units, 0/22.5/45 W, saturation, missing data, unplugged and discharge");
 }
}
