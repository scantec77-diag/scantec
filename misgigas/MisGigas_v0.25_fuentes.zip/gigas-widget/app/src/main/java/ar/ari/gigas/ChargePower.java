package ar.ari.gigas;

/** Net charging power at the battery, not the charger's input/nominal output. */
final class ChargePower {
 static final double MAX_WATTS = 45.0;
 static double watts(int plugged, int millivolts, int microamps) {
  if (plugged == 0) return 0.0;
  if (millivolts <= 0 || microamps == Integer.MIN_VALUE) return Double.NaN;
  return Math.max(0.0, (double) millivolts * microamps / 1e9);
 }
 static double ratio(double watts) {
  return Double.isFinite(watts) ? Math.max(0.0, Math.min(1.0, watts / MAX_WATTS)) : Double.NaN;
 }
}
