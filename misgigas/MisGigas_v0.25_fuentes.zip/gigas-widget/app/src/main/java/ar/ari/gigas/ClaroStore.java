package ar.ari.gigas;
import android.content.*;import android.net.Uri;import org.json.*;
final class ClaroStore {
 static final String START="https://miclaro.claro.com.ar/";
 static boolean trusted(String url){try{Uri u=Uri.parse(url);String h=u.getHost();return "https".equals(u.getScheme())&&h!=null&&(h.equals("claro.com.ar")||h.endsWith(".claro.com.ar"));}catch(Exception e){return false;}}
 static boolean busy(Context c){long t=Plan.prefs(c).getLong("claroBusy",0);return t>0&&System.currentTimeMillis()-t<120000;}
 static void error(Context c,String message){Plan.prefs(c).edit().putString("claroError",message).putLong("claroBusy",0).apply();GigasWidget.refresh(c);}
 static boolean linked(Context c){return !Plan.prefs(c).getString("claroLine","").isEmpty();}
 static boolean bind(Context c,String line,boolean allowed){
  if(!line.matches("[0-9]{8,15}"))return false;
  String old=Plan.prefs(c).getString("claroLine","");
  if(old.equals(line))return true;
  if(!old.isEmpty()||!allowed)return false;
  Plan.prefs(c).edit().putString("claroLine",line).apply();ClaroJobs.ensure(c);return true;
 }
 static void save(Context c,JSONObject result,String url)throws Exception{
  if(!trusted(url)||!linked(c)||!Plan.prefs(c).getString("claroLine","").equals(result.optString("line")))throw new IllegalArgumentException("No se identificó la línea de Claro; se conserva el saldo anterior");
  float left=(float)result.getDouble("left"),total=(float)result.getDouble("total"),configured=Plan.prefs(c).getFloat("clarototal",0);
  if(!Float.isFinite(left)||!Float.isFinite(total)||left<0||total<=0||left>total||Math.abs(configured-total)>.011f)throw new IllegalArgumentException("El total de Claro no coincide con el plan configurado; revisá los GB totales");
  Plan.prefs(c).edit().putFloat("claroleft",left).putLong("clarostamp",System.currentTimeMillis()).putString("clarosource","Claro web verificado").putString("claroError","").putLong("claroBusy",0).putBoolean("claroVerified",true).apply();ClaroJobs.ensure(c);GigasWidget.refresh(c);
 }
 static String script(Context c,String code,String selected){float configured=Plan.prefs(c).getFloat("clarototal",0);String total=Float.isFinite(configured)&&configured>0?Float.toString(configured):"null";return "window.__misGigasClaroTotal="+total+";"+"window.__misGigasClaroLine="+JSONObject.quote(Plan.prefs(c).getString("claroLine",""))+";window.__misGigasClaroSelected="+JSONObject.quote(selected)+";"+code;}
 static String loadScript(Context c)throws Exception{try(java.io.InputStream in=c.getAssets().open("claro-read.js")){java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return new String(out.toByteArray(),java.nio.charset.StandardCharsets.UTF_8);}}
}
